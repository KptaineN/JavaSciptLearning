---
type: sommaire
cours: JavaScript - ft_transcendence
tags: [javascript, 42, obsidian, parcours]
---

# JavaScript — Parcours en 12 leçons pour ft_transcendence

> [!abstract] Ton objectif
> Passer d'un profil qui connaît déjà les bases du C/C++ à un développeur capable de **lire, écrire, tester et expliquer** du JavaScript moderne pour une application web. Parcours en français ; exemples compatibles Node.js récent et navigateurs modernes.

## Mode d'emploi dans Obsidian

1. Extrais l'archive `.tar` puis **ouvre le dossier `JavaScript-Transcendence-Obsidian` comme coffre (vault)**, ou déplace son contenu dans ton vault existant.
2. Ouvre cette page : elle fait office de page d'accueil.
3. Suis les leçons dans l'ordre, **teste réellement** les extraits et fais les exercices **sans ouvrir les corrigés**.
4. Utilise les cases `- [ ]` des leçons pour suivre tes acquis ; change le champ `statut` du frontmatter si souhaité.
5. Le code exécutable et les annexes sont complémentaires ; certaines leçons contiennent des extraits autonomes, d'autres demandent de créer leur HTML.

> [!tip] Méthode d'apprentissage
> 20 min de lecture → 30 à 60 min de code → 15 min d'exercices → correction → explique la notion à voix haute comme si tu l'enseignais. Recommence à J+1 et J+7.

## Module 1 — Fondations

- [ ] [[01-Comprendre-JavaScript-et-son-environnement|01 · JavaScript et ses environnements]] — navigateur, Node.js, F12
- [ ] [[02-Variables-types-et-conversions|02 · Variables, types et conversions]] — `const`, `let`, `===`, `??`
- [ ] [[03-Conditions-boucles-et-erreurs|03 · Conditions, boucles, erreurs]] — garde, `for...of`, `try/catch`
- [ ] [[04-Fonctions-portee-et-closures|04 · Fonctions, portée et closures]] — fonctions-valeurs, capture, `this`

## Module 2 — Données et navigateur

- [ ] [[05-Tableaux-et-algorithmes|05 · Tableaux et algorithmes]] — `map`, `filter`, `reduce`, tri
- [ ] [[06-Objets-JSON-Map-et-Set|06 · Objets, JSON, Map, Set]] — représentation des données
- [ ] [[07-DOM-evenements-et-formulaires|07 · DOM, événements, formulaires]] — interface et validation
- [ ] [[08-Asynchronisme-Promises-et-fetch|08 · Async, Promises, fetch]] — requêtes HTTP et concurrence

## Module 3 — Construire et tester

- [ ] [[09-HTTP-et-API-avec-Node|09 · HTTP et API Node.js]] — méthodes, statuts, backend
- [ ] [[10-Modules-architecture-et-etat|10 · Modules, architecture, état]] — `import/export`, découpage
- [ ] [[11-WebSockets-et-temps-reel|11 · WebSocket et temps réel]] — diffusion à plusieurs clients
- [ ] [[12-Tests-debug-securite-et-integration|12 · Tests, debug et sécurité]] — fiabilité et préparation à l'évaluation

## Annexes

- [[Annexe-Installation-et-commandes|Installation, commandes, lancement des exemples]]
- [[Annexe-Aide-memoire-JavaScript-Cpp|Fiche de révision JavaScript ↔ C/C++]]
- [[Annexe-Corriges-des-exercices|Corrigés des 12 leçons]] — à consulter après avoir essayé
- [[Annexe-Ateliers-pratiques|Ateliers HTML / DOM / API / WebSocket]]
- [[Annexe-Projet-fil-rouge|Projet fil rouge : tableau de scores multi-utilisateur]]
- [[Annexe-Plan-de-tests-transcendence|Préparer les tests et cas Obsidian]]
- [[Annexe-Sujet-ft-transcendence|Lien précis avec le sujet ft_transcendence v21.2]]
- [[Annexe-Ressources-et-glossaire|Ressources officielles et glossaire]]
- [[Template-Cas-de-test|Modèle de cas de test à dupliquer]]
- [[Template-Fiche-de-revision|Modèle de fiche de révision]]

## Objectifs mesurables

| Étape | Tu sais faire sans aide |
|---|---|
| Après 04 | écrire une fonction validée avec des gardes + expliquer une closure |
| Après 06 | gérer une liste de joueurs, trier, sérialiser et vérifier du JSON |
| Après 08 | afficher une donnée d'API avec états chargement / succès / erreur |
| Après 10 | structurer trois modules JavaScript et faire une requête POST |
| Après 12 | synchroniser 2 clients dans un atelier, écrire et exécuter des tests |

## Compatibilité avec le sujet fourni

Le PDF **ft_transcendence, version 21.2** décrit une application Web **à imaginer en équipe** : **frontend + backend + base de données**, multi-utilisateur, déploiement conteneurisé, HTTPS, validation des saisies et console JavaScript propre. Le **jeu** et les **WebSockets** relèvent de modules optionnels selon le projet choisi. Les leçons utilisent souvent les joueurs et scores comme **exemples pédagogiques**, pas comme une obligation. Pour le détail : [[Annexe-Sujet-ft-transcendence]].

> [!note] Important
> Ce cours est une **préparation pédagogique originale** inspirée des contraintes du sujet. Il ne remplace ni le sujet officiel ni la documentation technique. Le backend d'entraînement utilise des exemples locaux simplifiés, non destinés à la production.
