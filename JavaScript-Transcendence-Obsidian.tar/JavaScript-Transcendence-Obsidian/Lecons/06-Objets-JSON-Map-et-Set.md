---
type: lecon
cours: JavaScript - ft_transcendence
numero: 06
niveau: Intermédiaire
statut: a-faire
tags: [javascript, objets]
---

# 06 — Objets, JSON, Map et Set

> [!abstract] Mission
> Modéliser les données d'une application multi-utilisateur. **75 à 90 min**.

## Objectifs
- [ ] Créer, accéder et copier des objets.
- [ ] Comprendre références et déstructuration.
- [ ] Utiliser `JSON.stringify` / `JSON.parse` sans confondre sérialisation et validation.
- [ ] Choisir entre objet, `Map` et `Set`.

## 1. Objet : une fiche utilisateur

```js
const utilisateur = {
  id: 42,
  pseudo: 'Ada',
  preferences: { theme: 'dark' },
  roles: ['user'],
};

console.log(utilisateur.pseudo);       // Ada
console.log(utilisateur['id']);        // 42
const { pseudo, id } = utilisateur;    // destructuration
console.log(pseudo, id);
```

L'accès `objet.cle` est pratique quand la clé est connue. `objet[cleDynamique]` sert lorsque son nom vient d'une variable.

## 2. Copie et références

```js
const a = { score: 0 };
const b = a;
b.score = 10;
console.log(a.score); // 10

const c = { ...a, score: 20 };
console.log(a.score, c.score); // 10, 20
```

`{ ...a }` produit une **copie superficielle**. Pour un schéma imbriqué, reconstruis les niveaux modifiés ou utilise `structuredClone` sur des données compatibles avec cette API.

## 3. JSON : format d'échange

```js
const partie = { id: 'p1', joueurs: ['Ada', 'Lin'], finie: false };
const texte = JSON.stringify(partie);
const copie = JSON.parse(texte);
console.log(texte);
console.log(copie.joueurs[1]); // Lin
```

JSON transporte des données, pas du code. Il ne représente pas directement les fonctions, `undefined`, `BigInt` ou les cycles de références ordinaires. L'analyse `JSON.parse` peut échouer :

```js
try {
  const donnees = JSON.parse('{pas du json}');
  console.log(donnees);
} catch (erreur) {
  console.error('JSON invalide');
}
```

> [!danger] Règle de sécurité
> Recevoir un JSON valide ne signifie **pas** recevoir des valeurs autorisées. Après `JSON.parse`, contrôle types, longueurs, bornes, droits d'accès et cohérence métier **côté serveur**.

## 4. `Map` pour des clés arbitraires

```js
const joueursParId = new Map();
joueursParId.set(42, { pseudo: 'Ada' });
joueursParId.set(7, { pseudo: 'Lin' });
console.log(joueursParId.get(42));
console.log(joueursParId.has(10)); // false
joueursParId.delete(7);

for (const [id, joueur] of joueursParId) {
  console.log(id, joueur.pseudo);
}
```

Une `Map` peut avoir des clés non textuelles (par exemple des nombres ou des objets), à la différence des clés d'un objet ordinaire (chaînes ou symboles). Très utile pour stocker les connexions actives en mémoire.

## 5. `Set` pour les éléments uniques

```js
const connectes = new Set(['Ada', 'Lin', 'Ada']);
console.log(connectes.size); // 2
connectes.add('Sam');
connectes.delete('Lin');
console.log(connectes.has('Ada')); // true
```

Un `Set` est utile pour une liste d'identifiants uniques ; il n'impose pas à lui seul la validité ni l'autorisation d'un identifiant.

## 6. Choisir une structure

| Besoin | Structure souvent adaptée |
|---|---|
| Une fiche utilisateur connue | Objet |
| Liste ordonnée de joueurs | Tableau |
| Connexions identifiées par socket ou ID | `Map` |
| IDs uniques dans une salle | `Set` |
| Payload entre navigateur et backend | JSON |

## Exercices

1. Modélise un match : `{ id, joueurA, joueurB, scores, statut }`. Affiche les noms.
2. Écris `ajouterAmi(utilisateur, nouvelId)` qui renvoie une **nouvelle** fiche avec un ID unique, sans modifier l'original.
3. Parse `'[{"id":1},{"id":2}]'` et calcule la somme des IDs.
4. Explique pourquoi `JSON.parse` ne suffit pas à sécuriser une API.

## Questions
- Quelles différences entre copie et référence ?
- Quand choisir `Map` plutôt qu'un objet ?
- Pourquoi un `Set` ne remplace-t-il pas une base de données ?

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 06]].


## Navigation

← [[05-Tableaux-et-algorithmes|Leçon précédente]] · [[00-Accueil|Parcours]] · [[07-DOM-evenements-et-formulaires|Leçon suivante]]
