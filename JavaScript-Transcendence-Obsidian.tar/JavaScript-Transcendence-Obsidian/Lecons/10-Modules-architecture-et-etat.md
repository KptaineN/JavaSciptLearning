---
type: lecon
cours: JavaScript - ft_transcendence
numero: 10
niveau: Intermédiaire
statut: a-faire
tags: [javascript, architecture]
---

# 10 — Modules, architecture et gestion de l'état

> [!abstract] Mission
> Structurer du JavaScript évolutif au lieu d'écrire tout dans `main.js`. **90 à 120 min**.

## Objectifs
- [ ] Utiliser `export` et `import` en ES modules.
- [ ] Séparer règles métier, appels réseau et interface.
- [ ] Comprendre une mise à jour d'état sans mutation involontaire.
- [ ] Évaluer les limites de `localStorage`.

## 1. Découper en modules

Arborescence possible :

```text
src/
  main.js             # point d'entrée et événements
  domain/scores.js    # règles métier pures
  api/joueurs.js      # requêtes HTTP
  ui/classement.js    # création d'éléments DOM
```

Dans `src/domain/scores.js` :

```js
export function ajouterPoints(score, gain) {
  if (!Number.isSafeInteger(score) || !Number.isSafeInteger(gain)) {
    throw new TypeError('Entiers attendus');
  }
  if (score < 0 || gain < 0) throw new RangeError('Valeurs négatives');
  const total = score + gain;
  if (!Number.isSafeInteger(total)) throw new RangeError('Dépassement');
  return total;
}
```

Dans `src/main.js` :

```js
import { ajouterPoints } from './domain/scores.js';
console.log(ajouterPoints(10, 3));
```

Dans un navigateur :

```html
<script type="module" src="./src/main.js"></script>
```

Les modules sont exécutés en mode strict et ont leur propre portée. Pour éviter les restrictions liées aux modules et aux fichiers locaux, utilise un **serveur HTTP de développement** plutôt que `file://` (par exemple `python3 -m http.server 8000` pour les fichiers statiques, sans faire de lui un backend).

## 2. Logique métier pure et effets de bord

```js
// Fonction pure : mêmes arguments => même résultat, sans modifier l'extérieur.
export function gagner(joueur, points) {
  return { ...joueur, score: joueur.score + points };
}

// Effet de bord : change l'interface.
export function afficherScore(element, joueur) {
  element.textContent = `Score : ${joueur.score}`;
}
```

Mélanger les deux rend les tests difficiles. Sépare **calcul**, **stockage**, **réseau** et **présentation** quand l'application grossit.

## 3. Un état minimal

```js
let etat = {
  joueurs: [],
  chargement: false,
  erreur: null,
};

function definirEtat(changement) {
  etat = { ...etat, ...changement };
  afficher(etat);
}

function afficher(etatCourant) {
  console.log(etatCourant);
}

definirEtat({ chargement: true });
```

Pour un vrai frontend, `afficher` mettrait à jour le DOM. Ce modèle rudimentaire permet de comprendre pourquoi des frameworks comme React, Vue ou Svelte facilitent l'organisation de l'interface ; ils ne sont pas indispensables pour **apprendre JavaScript**.

## 4. Synchroniser, sans confondre état et source de vérité

- **État local** : panneau actuellement ouvert, texte en cours de saisie, chargement.
- **État serveur** : comptes, scores réels, droits, invitations et résultats persistés.
- **Stockage navigateur** : `localStorage` sert à quelques préférences non sensibles, pas à constituer la seule source des scores ni à stocker des secrets d'authentification.

```js
localStorage.setItem('theme', 'dark');
const theme = localStorage.getItem('theme') ?? 'light';
console.log(theme);
```

Ce code fonctionne dans un navigateur disposant de cet espace de stockage ; il ne fonctionne pas tel quel dans Node.js. Les données peuvent être effacées et restent accessibles au JavaScript de la même origine : attention aux XSS.

## 5. Pourquoi une architecture aide les tests

Tu peux tester `ajouterPoints` sans DOM, navigateur ni serveur. Tu peux ensuite tester le DOM séparément, puis tester le vrai flux HTTP. Cette séparation reflète une stratégie **unitaire → intégration → E2E**.

## 6. Application à ft_transcendence

Le sujet propose, selon les modules sélectionnés, des frameworks frontend/backend, un design system réutilisable, une PWA et des collaborations temps réel. Ne choisis pas les modules uniquement parce qu'une technologie te plaît : ils doivent correspondre à l'idée de ton équipe et être **entièrement démontrables**.

## Exercices

1. Découpe une fonction monolithique `ajouterEtAfficherScore` en une fonction métier et une fonction DOM.
2. Écris `export function estPseudoValide(pseudo)` puis importe-la dans un autre module.
3. Indique pour chaque donnée sa source de vérité : thème sombre, mot de passe, score gagné, état du menu.
4. Pourquoi éviter une variable globale modifiée depuis dix endroits ?

## Questions
- Pourquoi la séparation UI/domaine/API est-elle utile ?
- `localStorage` est-il une base de données multi-utilisateur ?
- Pourquoi faut-il servir les modules navigateur par HTTP ?

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 10]].


## Navigation

← [[09-HTTP-et-API-avec-Node|Leçon précédente]] · [[00-Accueil|Parcours]] · [[11-WebSockets-et-temps-reel|Leçon suivante]]
