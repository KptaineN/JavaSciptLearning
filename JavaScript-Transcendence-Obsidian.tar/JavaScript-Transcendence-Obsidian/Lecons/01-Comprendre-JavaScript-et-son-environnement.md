---
type: lecon
cours: JavaScript - ft_transcendence
numero: 01
niveau: Débutant
statut: a-faire
tags: [javascript, fondamentaux]
---

# 01 — Comprendre JavaScript et son environnement

> [!abstract] Mission
> Comprendre **où s'exécute** JavaScript et exécuter tes premiers scripts dans un navigateur et dans Node.js. Durée indicative : **60 à 90 min**.

## Objectifs
- [ ] Distinguer JavaScript, ECMAScript, navigateur et Node.js.
- [ ] Exécuter un fichier `.js` et lire une erreur.
- [ ] Comprendre la séparation HTML / CSS / JavaScript.
- [ ] Faire le parallèle avec une compilation C/C++ sans chercher à coder du C en JavaScript.

## 1. Le modèle mental

**JavaScript** est un langage de programmation. **ECMAScript** est sa spécification. Le navigateur ajoute des interfaces comme `document`, `window`, `fetch` et `WebSocket`. **Node.js** est un environnement d'exécution hors du navigateur : il ajoute, entre autres, l'accès aux fichiers, au réseau et aux processus.

| En C/C++ à 42 | En JavaScript |
|---|---|
| `gcc main.c -o app` | `node app.js` (pas de compilation manuelle préalable) |
| `printf(...)` | `console.log(...)` |
| `int`, `char *`, `std::string` | Types généralement déterminés à l'exécution |
| `malloc/free` | Mémoire gérée automatiquement (garbage collector) |
| `main()` | Le code au niveau du module peut s'exécuter directement |

> [!warning] Ne pas confondre
> `document.querySelector()` marche dans un navigateur, **pas** dans un script Node.js ordinaire. À l'inverse, `node:fs` n'est pas une API du navigateur.

## 2. Premier programme dans Node.js

Vérifie que Node.js est installé :

```bash
node --version
mkdir -p apprentissage-js
cd apprentissage-js
printf 'console.log("Bonjour JavaScript !");\n' > bonjour.js
node bonjour.js
```

Résultat attendu : `Bonjour JavaScript !`.

```js
// Les commentaires de ligne commencent par //.
console.log('42', 'transcendence');
console.error('Un message de diagnostic');
```

`console.error` ne fait pas échouer automatiquement le programme ; pour représenter une erreur, on peut lancer une exception ou donner un code de sortie non nul (vu plus tard).

## 3. Premier programme dans le navigateur

Crée un fichier `index.html` :

```html
<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Découverte JS</title>
    <script src="main.js" defer></script>
  </head>
  <body>
    <h1 id="titre">Bonjour</h1>
  </body>
</html>
```

Puis `main.js` :

```js
const titre = document.querySelector('#titre');
titre.textContent = 'Je découvre JavaScript';
console.log('Page prête');
```

Ouvre la page dans un navigateur. Affiche les **outils de développement** (F12), onglets **Console**, **Sources** et **Réseau**. L'attribut `defer` fait exécuter le script externe après l'analyse du HTML, dans l'ordre de ses apparitions.

## 4. Reconnaître l'origine d'une erreur

```js
console.log(joueur);
```

Ici, `joueur` n'existe pas : tu verras une `ReferenceError`. Apprends à lire le **type**, le **message**, puis le **fichier:ligne**. Un stack trace joue un rôle comparable à une backtrace avec `gdb`.

## 5. JavaScript et ft_transcendence

Ton sujet **ft_transcendence v21.2** impose une application Web avec **frontend, backend et base de données** ; il impose aussi de ne laisser **aucune erreur ou avertissement JavaScript dans la console du navigateur**. Il ne dit pas que toute l'application doit être écrite en JavaScript : nous l'étudions parce qu'il constitue une voie pratique pour le frontend et éventuellement le backend.

Schéma possible, **choix technique et non obligation du sujet** :

```text
Navigateur (HTML + CSS + JS)
          | HTTPS / JSON
          v
     Backend (Node.js)
          |
          v
    Base de données
```

## 6. Exercices sans regarder le corrigé

1. Écris `presentation.js` qui affiche un prénom, un langage connu et un langage à apprendre.
2. Crée une page avec un `<p id="etat">En attente</p>` et change son texte depuis un fichier `.js`.
3. Exécute volontairement `console.log(inconnu)` ; relève le **nom de l'erreur** et sa ligne.

## Questions de compréhension
- Quelle est la différence entre JavaScript et Node.js ?
- Pourquoi `document` n'est-il pas accessible directement dans Node.js ?
- À quoi sert `defer` ?

> [!success] Critère de réussite
> Tu peux expliquer le trajet navigateur → backend et lancer un exemple **sans copier les commandes**.

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 01]].


## Navigation

← [[00-Accueil|Sommaire]] · [[00-Accueil|Parcours]] · [[02-Variables-types-et-conversions|Leçon suivante]]
