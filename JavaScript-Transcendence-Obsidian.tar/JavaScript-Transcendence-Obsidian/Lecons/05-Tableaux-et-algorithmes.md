---
type: lecon
cours: JavaScript - ft_transcendence
numero: 05
niveau: Intermédiaire
statut: a-faire
tags: [javascript, tableaux]
---

# 05 — Tableaux et algorithmes

> [!abstract] Mission
> Traiter des collections comme les joueurs, les scores et les parties. **90 min**.

## Objectifs
- [ ] Créer et parcourir des tableaux.
- [ ] Distinguer `.map()`, `.filter()`, `.find()`, `.some()`, `.every()`, `.reduce()`.
- [ ] Trier sans modifier les données d'origine si nécessaire.
- [ ] Éviter les références partagées involontaires.

## 1. Indexation, longueur et copie

```js
const joueurs = ['Ada', 'Lin', 'Noé'];
console.log(joueurs[0]);         // Ada
console.log(joueurs.length);     // 3
console.log(joueurs.at(-1));     // Noé

const copie = [...joueurs];      // nouveau tableau, copie superficielle
copie.push('Sam');
console.log(joueurs.length);     // toujours 3
```

`push`, `pop`, `splice`, `sort` **modifient** le tableau ; `map`, `filter`, `slice` créent de nouveaux tableaux. Le spread `[...]` ne copie pas récursivement les objets contenus.

## 2. Transformation de collections

```js
const scores = [
  { pseudo: 'Ada', points: 12, actif: true },
  { pseudo: 'Lin', points: 3, actif: false },
  { pseudo: 'Sam', points: 8, actif: true },
];

const noms = scores.map((j) => j.pseudo);
const actifs = scores.filter((j) => j.actif);
const sam = scores.find((j) => j.pseudo === 'Sam');
const top10 = scores.some((j) => j.points >= 10);
const tousPositifs = scores.every((j) => j.points >= 0);

console.log(noms, actifs, sam, top10, tousPositifs);
```

| Méthode | Intention | Résultat |
|---|---|---|
| `map` | transformer chaque élément | tableau de même longueur |
| `filter` | conserver ceux qui satisfont un prédicat | nouveau tableau |
| `find` | trouver le premier élément | élément ou `undefined` |
| `some` | au moins un ? | booléen |
| `every` | tous ? | booléen |
| `reduce` | agréger dans un accumulateur | valeur calculée |

## 3. Réduire et trier

```js
const total = scores.reduce((somme, j) => somme + j.points, 0);
const classement = [...scores].sort((a, b) => b.points - a.points);
console.log(total);                     // 23
console.log(classement[0].pseudo);      // Ada
console.log(scores[0].pseudo);         // Ada ; tableau d'origine non trié
```

Sans comparateur, `.sort()` trie par représentation **textuelle** : `[2, 10].sort()` produit `[10, 2]`. Dans le doute, fournit un comparateur numérique. `toSorted()` permet aussi de produire un tableau trié sans mutation, dans les environnements récents.

## 4. Éviter la mutation des objets

```js
const originaux = [{ pseudo: 'Ada', points: 2 }];
const superficielle = [...originaux];
superficielle[0].points = 99;
console.log(originaux[0].points); // 99 : même objet interne !
```

Pour mettre à jour un élément sans toucher à l'ancien :

```js
const nouveaux = originaux.map((j) =>
  j.pseudo === 'Ada' ? { ...j, points: 100 } : j
);
```

Ce modèle sera pratique pour gérer l'état d'une interface.

## 5. Algorithme guidé : top N

```js
function topJoueurs(joueurs, limite) {
  if (!Number.isInteger(limite) || limite < 0) {
    throw new RangeError('limite invalide');
  }
  return [...joueurs]
    .filter((joueur) => joueur.actif)
    .sort((a, b) => b.points - a.points)
    .slice(0, limite);
}
```

Ordre des opérations : filtrer → trier → limiter. Complexité dominante du tri : typiquement `O(n log n)`, contre `O(n)` pour filtrer.

## Exercices

1. À partir de `[4, 8, 2, 10]`, produire les valeurs **paires et supérieures à 4**, puis leur somme.
2. Créer `moyenneScores(joueurs)` ; le tableau vide doit renvoyer `null` et non `NaN`.
3. Créer un classement par `points` décroissants sans modifier le tableau d'entrée.
4. Expliquer pourquoi `[...joueurs]` ne suffit pas à copier profondément les objets.

## Vérification
- Différence entre `find` et `filter` ?
- Quelle méthode est dangereuse si tu souhaites conserver l'ordre original ?
- Pourquoi l'accumulateur initial est-il important avec `reduce` ?

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 05]].


## Navigation

← [[04-Fonctions-portee-et-closures|Leçon précédente]] · [[00-Accueil|Parcours]] · [[06-Objets-JSON-Map-et-Set|Leçon suivante]]
