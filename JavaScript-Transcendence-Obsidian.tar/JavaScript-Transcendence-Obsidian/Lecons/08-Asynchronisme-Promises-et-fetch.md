---
type: lecon
cours: JavaScript - ft_transcendence
numero: 08
niveau: Intermédiaire
statut: a-faire
tags: [javascript, async]
---

# 08 — Asynchronisme, Promises et fetch

> [!abstract] Mission
> Comprendre comment une application gère le réseau **sans figer l'interface**. **100 min**.

## Objectifs
- [ ] Expliquer pile d'appels, file de tâches et microtâches.
- [ ] Utiliser `Promise`, `.then()` et `async/await`.
- [ ] Distinguer erreur réseau et réponse HTTP non-2xx.
- [ ] Gérer les chargements, erreurs et annulations.

## 1. Pourquoi l'asynchrone ?

Une demande réseau prend du temps. JavaScript ne doit pas attendre activement dans une boucle `while` pendant qu'un serveur répond. Le navigateur peut poursuivre d'autres tâches ; une Promise représente une opération dont le résultat viendra plus tard.

```js
console.log('A');
setTimeout(() => console.log('B'), 0);
Promise.resolve().then(() => console.log('C'));
console.log('D');
// Ordre usuel : A, D, C, B
```

Explication : `A` et `D` sont synchrones. Une réaction `.then()` va dans la file des **microtâches**, traitée après le code courant, avant la prochaine tâche du timer. Cela ne signifie pas que toutes les opérations asynchrones sont parallèles.

## 2. Promise et erreurs

```js
function attendre(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

attendre(200).then(() => console.log('200 ms écoulées'));
```

Une Promise peut être **pending**, **fulfilled** ou **rejected**. `async` enveloppe le résultat d'une fonction dans une Promise ; `await` attend son règlement **sans bloquer le thread principal** de la même manière qu'une boucle synchrone.

```js
async function demonstration() {
  try {
    await attendre(100);
    return 'prêt';
  } catch (erreur) {
    console.error(erreur);
    throw erreur;
  }
}
demonstration().then(console.log);
```

## 3. `fetch` : lire une API HTTP

```js
async function chargerJoueurs() {
  const reponse = await fetch('/api/joueurs');
  if (!reponse.ok) {
    throw new Error(`HTTP ${reponse.status}`);
  }
  const donnees = await reponse.json();
  if (!Array.isArray(donnees)) throw new TypeError('Format inattendu');
  return donnees;
}
```

Une réponse **404 ou 500 ne rejette pas automatiquement** la Promise `fetch`. C'est pour cela que nous testons `reponse.ok`. Un problème réseau ou une annulation rejette généralement l'opération ; `reponse.json()` peut aussi échouer sur un corps invalide.

## 4. Afficher les trois états : chargement / succès / échec

```js
async function rafraichirListe() {
  const message = document.querySelector('#etat');
  message.textContent = 'Chargement…';
  try {
    const joueurs = await chargerJoueurs();
    message.textContent = `${joueurs.length} joueur(s) chargé(s)`;
  } catch (erreur) {
    console.error('Chargement impossible :', erreur);
    message.textContent = 'Impossible de charger les joueurs.';
  }
}
```

Un `try/catch` rend l'échec explicite. En production, évite d'afficher des traces ou secrets côté utilisateur.

## 5. Lancer plusieurs requêtes

```js
async function chargerPage() {
  const [profil, classement] = await Promise.all([
    fetch('/api/profil').then(verifierEtLire),
    fetch('/api/classement').then(verifierEtLire),
  ]);
  return { profil, classement };
}

async function verifierEtLire(reponse) {
  if (!reponse.ok) throw new Error(`HTTP ${reponse.status}`);
  return reponse.json();
}
```

`Promise.all` rejette si une de ses Promises rejette. Si tu veux collecter succès et échecs indépendants, découvre `Promise.allSettled`.

## 6. Annulation et requêtes obsolètes

```js
const controleur = new AbortController();
fetch('/api/recherche?q=pong', { signal: controleur.signal })
  .catch((erreur) => {
    if (erreur.name !== 'AbortError') console.error(erreur);
  });
controleur.abort();
```

L'annulation évite notamment de continuer une requête lorsqu'on quitte un écran. Elle ne garantit pas que le serveur a interrompu son propre traitement.

## 7. Application à ft_transcendence

Requêtes asynchrones : inscription, connexion, liste de parties, classement, historique. Pour de la **communication instantanée récurrente**, WebSocket sera étudié en leçon 11.

## Exercices

1. Prédire l'ordre d'affichage dans l'exemple A/B/C/D et l'expliquer.
2. Écris `async attendreEtDoubler(n)` qui attend 100 ms puis renvoie `n * 2`.
3. Modifie `chargerJoueurs` pour traiter explicitement un 401 avec un message « Non connecté ».
4. Énumère les erreurs possibles lors d'un `fetch` + `response.json()`.

## Questions
- `await` rend-il la fonction appelante synchrone ?
- `fetch` rejette-t-il sur HTTP 404 ?
- Pourquoi afficher un état « chargement » ?

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 08]].


## Navigation

← [[07-DOM-evenements-et-formulaires|Leçon précédente]] · [[00-Accueil|Parcours]] · [[09-HTTP-et-API-avec-Node|Leçon suivante]]
