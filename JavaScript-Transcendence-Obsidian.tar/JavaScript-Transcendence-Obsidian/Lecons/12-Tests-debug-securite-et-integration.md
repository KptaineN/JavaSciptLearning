---
type: lecon
cours: JavaScript - ft_transcendence
numero: 12
niveau: Avancé
statut: a-faire
tags: [javascript, tests]
---

# 12 — Tests, débogage, sécurité et intégration

> [!abstract] Mission
> Prouver que le code fonctionne : tests unitaires, API, navigateur, erreurs et sécurité. **120 min**.

## Objectifs
- [ ] Écrire des tests unitaires natifs Node.js.
- [ ] Distinguer unitaires, intégration, E2E, manuels et charge.
- [ ] Déboguer avec stack trace et breakpoints.
- [ ] Établir un plan de tests concret pour ft_transcendence.

## 1. Test unitaire sans bibliothèque externe

`score.mjs` :

```js
export function calculerScore(score, gain) {
  if (!Number.isSafeInteger(score) || !Number.isSafeInteger(gain)) {
    throw new TypeError('Entiers attendus');
  }
  if (score < 0 || gain < 0 || !Number.isSafeInteger(score + gain)) {
    throw new RangeError('Score invalide');
  }
  return score + gain;
}
```

`score.test.mjs` :

```js
import test from 'node:test';
import assert from 'node:assert/strict';
import { calculerScore } from './score.mjs';

test('additionne deux entiers', () => {
  assert.equal(calculerScore(2, 3), 5);
});

test('rejette une valeur négative', () => {
  assert.throws(() => calculerScore(2, -1), RangeError);
});
```

Exécute `node --test score.test.mjs`. Dans `Exemples/`, une version prête à lancer figure avec d'autres tests.

## 2. Pyramide de tests appliquée à l'app

| Couche | Exemple | Outils possibles |
|---|---|---|
| Unitaire | calcul de score, validation | `node:test`, Vitest |
| Intégration | route POST avec vraie validation | `curl`, Postman, tests API |
| E2E | inscription → connexion → jouer | Playwright, Robot Framework |
| Manuel | clavier, lisibilité, message d'erreur | navigateur + checklist |
| Charge | beaucoup d'utilisateurs simultanés | k6, JMeter, autres outils dédiés |

Les outils sont des options : le sujet n'impose pas précisément ceux-ci. Une stratégie réaliste comporte aussi des tests de concurrence, de sécurité et de compatibilité navigateur.

## 3. Un cas de test avant le code

```text
ID : AUTH-03
Objet : connexion avec mauvais mot de passe
Précondition : compte existant
Étapes : saisir email valide, mot de passe erroné, valider
Résultat attendu : connexion refusée, aucun accès au compte,
                  message compréhensible, pas de données sensibles
Priorité : haute
```

Le modèle complet Obsidian est dans [[Template-Cas-de-test]].

## 4. Déboguer dans le navigateur

1. Ouvre F12 → **Console** : repère erreur, source et numéro de ligne.
2. Dans **Sources**, pose un breakpoint avant l'instruction fautive.
3. Regarde variables locales, pile d'appels et étapes (*step over*, *step into*).
4. Dans **Network**, examine requête, code HTTP, payload et réponse.
5. Ne conserve aucun `console.error` involontaire ni warning JavaScript dans la version évaluée.

Dans Node.js, tu peux aussi utiliser `node --inspect-brk serveur.mjs` pour un débogueur compatible.

## 5. Sécurité : le modèle des frontières

**Tout ce qui arrive du client est non fiable.** Tu dois valider à l'entrée serveur et vérifier les autorisations pour chaque action. Quelques règles :

- **XSS** : préfère `textContent`; encode/sanétise selon le contexte si du HTML doit vraiment être accepté.
- **Injection SQL** : requêtes paramétrées, jamais concaténer l'entrée en SQL.
- **Authentification** : hachage salé via des fonctions adaptées (Argon2id/bcrypt/scrypt selon l'architecture), cookies de session correctement configurés si employés.
- **Autorisation** : « connecté » ne veut pas dire « autorisé à modifier ce score ».
- **Secrets** : `.env` ignoré par Git ; `.env.example` sans véritables secrets.
- **HTTPS/WSS** : obligatoire pour les connexions externes au backend du projet.
- **Protection des données** : prévoir pages Privacy Policy / Terms of Service pertinentes et accessibles.

Le projet doit aussi gérer simultanément plusieurs utilisateurs sans collisions et erreurs de synchronisation. Une réussite sur ton poste ne prouve pas le bon comportement à deux clients.

## 6. Matrice minimale pour ft_transcendence

| ID | Scénario | Attendu |
|---|---|---|
| WEB-01 | ouvrir accueil sur Chrome récent | page responsive, sans erreur JS |
| AUTH-01 | mot de passe incorrect | refus sans fuite d'information |
| AUTH-02 | accès à ressource d'un autre compte | interdit |
| INPUT-01 | pseudo trop long / JSON malformé | rejet côté backend |
| CONC-01 | deux clients créent simultanément | pas de conflit d'ID |
| REAL-01 | deux clients reçoivent un événement | états cohérents |
| REAL-02 | un joueur se déconnecte | présence actualisée |
| SEC-01 | client manipule son score local | serveur ne valide pas la triche |
| LEGAL-01 | liens vers pages légales | pages pertinentes et visibles |

Les scénarios liés au temps réel/jeu deviennent nécessaires **si ton équipe choisit ces fonctions**. Le projet est libre dans son concept et ses modules ; l'app peut être autre chose qu'un Pong.

## 7. Atelier final

Construis le [[Annexe-Projet-fil-rouge|mini-projet fil rouge]] et donne-toi ce défi : **écrire les cas de test avant la fonctionnalité**. Chaque bug doit produire au moins un nouveau test de régression.

## Exercices

1. Ajoute deux tests : score zéro valide ; décimal refusé.
2. Écris un cas de test pour une double connexion simultanée.
3. Explique différence entre XSS, injection SQL et défaut d'autorisation.
4. Liste quatre vérifications avant une peer-évaluation.

## Questions
- Pourquoi le code de validation doit-il tourner aussi côté backend ?
- Quand un test manuel apporte-t-il quelque chose qu'un test unitaire ne couvre pas ?
- Comment éviter que le score d'un joueur soit défini uniquement par le navigateur ?

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 12]].


## Navigation

← [[11-WebSockets-et-temps-reel|Leçon précédente]] · [[00-Accueil|Parcours]] · [[Annexe-Projet-fil-rouge|Passer au projet fil rouge]]
