---
type: lecon
cours: JavaScript - ft_transcendence
numero: 02
niveau: Débutant
statut: a-faire
tags: [javascript, types]
---

# 02 — Variables, types et conversions

> [!abstract] Mission
> Comprendre ce que contiennent les variables et éviter les erreurs de comparaison / conversion. **75 à 90 min**.

## Objectifs
- [ ] Choisir entre `const` et `let`.
- [ ] Connaître les types primitifs et les valeurs spéciales.
- [ ] Utiliser `===`, `??`, `?.` et les chaînes interpolées.
- [ ] Expliquer ce qu'est une valeur *truthy/falsy*.

## 1. Déclarer correctement

```js
const pseudo = 'neo'; // la variable ne sera pas réassignée
let score = 0;       // la variable peut changer
score = score + 10;
console.log(`${pseudo} : ${score} points`);
```

`const` **interdit la réassignation**, mais ne rend pas un objet ou tableau immuable. Évite `var` dans du code moderne : sa portée et son hoisting surprennent facilement.

```js
const profil = { pseudo: 'neo' };
profil.pseudo = '42'; // autorisé : l'objet est modifié
// profil = {};       // TypeError : réassignation interdite
```

## 2. Types de données

| Valeur | Type renvoyé par `typeof` | Remarque |
|---|---|---|
| `42`, `3.14`, `NaN` | `number` | Nombre flottant IEEE 754 le plus courant |
| `42n` | `bigint` | Entier de précision arbitraire |
| `'hello'` | `string` | Chaîne immuable |
| `true` | `boolean` | Booléen |
| `undefined` | `undefined` | Valeur absente/non fournie |
| `null` | `object` | **Exception historique** de `typeof` |
| `{}` / `[]` | `object` | Objets par référence |
| `() => 1` | `function` | Une fonction est un objet appelable |
| `Symbol('id')` | `symbol` | Identifiant unique |

**Attention :** `0.1 + 0.2 !== 0.3` à cause de la représentation flottante. Pour une somme de scores entiers, reste sur des entiers sûrs (`Number.isSafeInteger`).

## 3. Comparer : `===` par défaut

```js
console.log(7 == '7');  // true : conversion implicite
console.log(7 === '7'); // false : types différents
console.log(7 !== '7'); // true
```

Utilise `===` / `!==` pour éviter les conversions implicites. Les **objets** se comparent par identité :

```js
console.log({ id: 1 } === { id: 1 }); // false
const a = { id: 1 };
const b = a;
console.log(a === b); // true
```

## 4. Truthy, falsy et valeurs manquantes

Les valeurs falsy comprennent `false`, `0`, `-0`, `0n`, `''`, `null`, `undefined`, `NaN`. Les tableaux et objets **même vides** sont truthy.

```js
const score = 0;
console.log(score || 100); // 100 : attention, 0 est falsy
console.log(score ?? 100); // 0 : seul null/undefined déclenche le défaut

const joueur = { profil: { pseudo: 'Lin' } };
console.log(joueur.profil?.pseudo ?? 'Anonyme'); // Lin
```

`?.` évite une erreur quand le segment de gauche vaut `null` ou `undefined`. Il ne corrige pas une faute de nom de variable non déclarée.

## 5. Conversions explicites

```js
const champ = '12';
const points = Number(champ);
console.log(points + 1); // 13
console.log(Number('12px')); // NaN
console.log(Number.isNaN(Number('abc'))); // true
console.log(String(42)); // '42'
console.log(Boolean('false')); // true, car chaîne non vide
```

Pour un formulaire, une entrée est souvent une **chaîne**, même si elle représente un nombre. Vérifie à la fois sa syntaxe, sa valeur et son intervalle.

```js
function lireScore(saisie) {
  if (typeof saisie !== 'string' || !/^\d+$/.test(saisie)) return null;
  const n = Number(saisie);
  return Number.isSafeInteger(n) && n <= 9999 ? n : null;
}
console.log(lireScore('0042')); // 42
console.log(lireScore('-1'));   // null
```

## 6. Pièges fréquents pour un développeur C++

- Pas de surcharge arbitraire des opérateurs pour des objets ordinaires.
- `+` concatène si l'un des opérandes devient une chaîne (`'2' + 2` → `'22'`).
- `NaN === NaN` vaut `false` ; préfère `Number.isNaN()`.
- `null` et `undefined` sont différents ; choisis consciemment tes valeurs absentes.

## Exercices

1. Écris `afficherScore(pseudo, score)` qui affiche `"Ada a 0 point(s)"` sans remplacer 0 par une valeur par défaut.
2. Prédire **puis vérifier** : `typeof null`, `Boolean([])`, `'5' + 2`, `'5' - 2`, `0 ?? 10`.
3. Écris `validerAge(texte)` : entier décimal de 0 à 120 inclus, sinon `null`.

## Mini-quiz
- Quelle différence entre `const` et immutabilité ?
- Pourquoi `||` est risqué avec un score valant 0 ?
- Deux objets de même contenu sont-ils forcément `===` ?

> [!success] Critère de réussite
> Tu ne compares plus un identifiant numérique à une chaîne sans conversion explicite.

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 02]].


## Navigation

← [[01-Comprendre-JavaScript-et-son-environnement|Leçon précédente]] · [[00-Accueil|Parcours]] · [[03-Conditions-boucles-et-erreurs|Leçon suivante]]
