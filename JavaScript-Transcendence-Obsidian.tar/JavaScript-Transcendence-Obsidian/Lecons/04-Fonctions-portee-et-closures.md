---
type: lecon
cours: JavaScript - ft_transcendence
numero: 04
niveau: Intermédiaire
statut: a-faire
tags: [javascript, fonctions]
---

# 04 — Fonctions, portée et closures

> [!abstract] Mission
> Comprendre comment JavaScript manipule les fonctions, l'état et les variables capturées. **90 min**.

## Objectifs
- [ ] Déclarer fonctions ordinaires et fléchées.
- [ ] Comprendre paramètres, retour, valeurs par défaut.
- [ ] Expliquer portée lexicale et closure.
- [ ] Éviter les erreurs courantes avec `this`.

## 1. Une fonction est une valeur

```js
function doubler(n) { return n * 2; }
const tripler = (n) => n * 3;
const operation = doubler;
console.log(operation(4)); // 8

function appliquer(valeur, fonction) {
  return fonction(valeur);
}
console.log(appliquer(5, tripler)); // 15
```

Une fonction peut être passée à une autre fonction (callback) ou renvoyée. Ce principe est central pour les événements et la programmation asynchrone.

## 2. Paramètres / retour / destructuration

```js
function saluer(pseudo = 'Invité') {
  return `Bienvenue, ${pseudo}`;
}

function resumer({ pseudo, score = 0 }) {
  return `${pseudo} : ${score}`;
}

console.log(saluer());
console.log(resumer({ pseudo: 'Ada' }));
```

Attention : la valeur par défaut `score = 0` s'applique si la propriété vaut `undefined`, pas si elle vaut `null`.

## 3. Portée lexicale (scope)

```js
const serveur = 'local';
function creerPartie() {
  const code = 'ABC';
  if (true) {
    const tour = 1;
    console.log(code, tour, serveur);
  }
  // console.log(tour); // ReferenceError
}
```

`let` et `const` ont une **portée de bloc**. Une fonction peut accéder aux variables de son environnement de **déclaration**.

## 4. Closure : un compteur privé

```js
function creerCompteur() {
  let valeur = 0;
  return function incrementer() {
    valeur += 1;
    return valeur;
  };
}

const compteurA = creerCompteur();
const compteurB = creerCompteur();
console.log(compteurA(), compteurA(), compteurB()); // 1 2 1
```

Chaque appel à `creerCompteur` crée un environnement distinct. Le compteur n'est pas global, mais continue d'exister tant que la fonction interne le référence. **Analogie C++ :** une closure ressemble à un objet qui conserve un état privé, mais le mécanisme est différent.

## 5. `this` : source majeure de bugs

```js
const joueur = {
  pseudo: 'Lin',
  afficher() { return this.pseudo; },
};
console.log(joueur.afficher()); // Lin

const afficher = joueur.afficher;
// afficher() n'a plus le même receveur ; en mode strict, this vaut undefined.
console.log(afficher.call(joueur)); // Lin
```

Les fonctions fléchées ne créent pas leur propre `this` : elles capturent celui de l'environnement. Elles sont pratiques pour un callback **mais pas pour une méthode qui dépend d'un `this` dynamique**.

```js
const joueur2 = {
  pseudo: 'Ada',
  afficher: () => this.pseudo, // mauvais choix pour cette méthode
};
```

## 6. Petite fonction, responsabilité unique

```js
const estScoreValide = (score) => Number.isInteger(score) && score >= 0;

function ajouterPoints(joueur, gain) {
  if (!estScoreValide(gain)) throw new RangeError('gain invalide');
  return { ...joueur, score: joueur.score + gain };
}
```

Cette version renvoie un nouvel objet, ce qui simplifie les tests et évite les modifications involontaires d'état partagé.

## Exercices

1. Écris `creerMultiplicateur(facteur)` qui renvoie une fonction de multiplication.
2. Écris `creerScore(initial = 0)` qui expose un objet `{ ajouter, lire }` sans rendre sa variable interne directement accessible.
3. Explique ce que valent `a()` et `b()` après création de deux compteurs indépendants.
4. Transforme `function pair(n) { return n % 2 === 0; }` en fonction fléchée.

## Questions
- Qu'est-ce que la portée lexicale ?
- Pourquoi deux closures peuvent-elles stocker deux états différents ?
- Dans quel cas une méthode fléchée risque-t-elle d'être problématique ?

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 04]].


## Navigation

← [[03-Conditions-boucles-et-erreurs|Leçon précédente]] · [[00-Accueil|Parcours]] · [[05-Tableaux-et-algorithmes|Leçon suivante]]
