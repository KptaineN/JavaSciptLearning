---
type: lecon
cours: JavaScript - ft_transcendence
numero: 11
niveau: Avancé
statut: a-faire
tags: [javascript, websocket]
---

# 11 — WebSockets et temps réel

> [!abstract] Mission
> Passer d'une requête ponctuelle à une connexion persistante pour plusieurs utilisateurs. **120 min**.

## Objectifs
- [ ] Distinguer HTTP, polling et WebSocket.
- [ ] Comprendre ouverture, message, erreur et fermeture.
- [ ] Diffuser des événements à plusieurs clients.
- [ ] Identifier les problèmes de latence, synchronisation et sécurité.

## 1. Du serveur IRC au WebSocket

Tu connais déjà le principe d'un serveur qui garde plusieurs clients connectés et diffuse des messages. Avec **WebSocket**, le navigateur obtient une connexion bidirectionnelle persistante après une négociation HTTP. On reçoit des **messages WebSocket**, pas forcément des lignes terminées par `\n` comme dans un protocole texte personnalisé. **Ne pars pas du principe** qu'une réception réseau bas niveau est un message applicatif complet : utilise l'API de la bibliothèque.

```text
Client A ----\
             > Serveur WebSocket ---- état de la partie
Client B ----/
```

## 2. Client navigateur

```js
const ws = new WebSocket('ws://127.0.0.1:8080');

ws.addEventListener('open', () => {
  ws.send(JSON.stringify({ type: 'chat', texte: 'Bonjour' }));
});

ws.addEventListener('message', (event) => {
  try {
    const message = JSON.parse(event.data);
    console.log('Reçu :', message);
  } catch {
    console.error('Message non JSON');
  }
});

ws.addEventListener('close', () => console.log('Déconnecté'));
ws.addEventListener('error', () => console.error('Erreur WebSocket'));
```

Le code est conçu pour être exécuté dans une page Web. `ws://` correspond à une démo locale ; en production, le navigateur doit utiliser **`wss://`** pour rester cohérent avec l'exigence HTTPS du sujet.

## 3. Serveur de démonstration avec `ws`

La bibliothèque `ws` s'installe explicitement :

```bash
mkdir demo-ws && cd demo-ws
npm init -y
npm install ws
```

Dans `serveur.mjs` :

```js
import { WebSocketServer, WebSocket } from 'ws';

const serveur = new WebSocketServer({
  host: '127.0.0.1',
  port: 8080,
  maxPayload: 4096,
});

serveur.on('connection', (client) => {
  client.send(JSON.stringify({ type: 'bienvenue' }));

  client.on('message', (donnees, estBinaire) => {
    if (estBinaire) return;
    let message;
    try {
      message = JSON.parse(donnees.toString('utf8'));
    } catch {
      return;
    }
    if (message.type !== 'chat' || typeof message.texte !== 'string' ||
        message.texte.length > 200) return;

    const reponse = JSON.stringify({ type: 'chat', texte: message.texte });
    for (const autre of serveur.clients) {
      if (autre !== client && autre.readyState === WebSocket.OPEN) {
        autre.send(reponse);
      }
    }
  });
});

console.log('Serveur WS local sur ws://127.0.0.1:8080');
```

Démarre `node serveur.mjs`. Ouvre **deux pages** contenant le client en leçon 11, ou utilise l'exemple HTML fourni dans `Exemples/ws-client.html`. Chaque client envoie un message à la connexion et reçoit ceux des autres clients.

> [!warning] Cette démo n'est pas un chat prêt pour Internet
> Elle ne gère ni identification, ni autorisation, ni historique, ni limitation de fréquence, ni backpressure, ni reconnexion, ni contrôle d'origine. Ne fais pas confiance au pseudo/id fourni par le client : associe l'identité authentifiée à la connexion côté serveur.

## 4. États, latence et cohérence

Pour un jeu multijoueur, une approche robuste consiste à considérer **le serveur comme autorité sur l'état** :

1. Client A envoie une intention (`MOVE_LEFT`).
2. Serveur valide identité, tour de jeu et règle.
3. Serveur actualise l'état.
4. Serveur diffuse l'état (ou un événement vérifié) aux clients autorisés.

Cela évite que chaque client décide seul « j'ai gagné ». Pour un Pong rapide, on peut ajouter timestamps, interpolation côté client et fréquence d'émission maîtrisée.

## 5. Déconnexions et clients lents

- `close` doit mettre à jour les présences et nettoyer les ressources associées.
- Un client lent peut accumuler les données en sortie : surveille la mémoire tampon (`bufferedAmount` selon le contexte), limite les files, et définis une politique explicite (coalescer les états éphémères, couper une connexion pathologiquement lente, etc.).
- Les reconnexions demandent une stratégie d'authentification et de récupération d'état : une socket fermée ne « reprend » pas automatiquement une partie.
- La sécurité d'origine, les permissions, le débit et les tailles des messages doivent être contrôlés.

## Exercices

1. Lance deux onglets et observe les messages croisés.
2. Modifie le serveur pour envoyer `{type: 'presence', nb: ...}` lors d'une connexion/fermeture.
3. Décris ce qui se passe si un joueur envoie `{type: 'chat', texte: 42}`.
4. Dessine une séquence serveur autoritaire pour l'action « marquer un point ».

## Questions
- Pourquoi WebSocket ne remplace-t-il pas toutes les routes HTTP ?
- Qui doit décider du score final ?
- Pourquoi un client lent représente-t-il un problème de mémoire / débit ?

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 11]].


## Navigation

← [[10-Modules-architecture-et-etat|Leçon précédente]] · [[00-Accueil|Parcours]] · [[12-Tests-debug-securite-et-integration|Leçon suivante]]
