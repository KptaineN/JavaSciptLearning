---
type: lecon
cours: JavaScript - ft_transcendence
numero: 07
niveau: Intermédiaire
statut: a-faire
tags: [javascript, frontend]
---

# 07 — DOM, événements et formulaires

> [!abstract] Mission
> Créer une interface interactive, accessible et sûre. **90 à 120 min**.

## Objectifs
- [ ] Trouver un élément du DOM et modifier son contenu.
- [ ] Comprendre `addEventListener` et `event.preventDefault()`.
- [ ] Lire un formulaire, valider une saisie et afficher les erreurs.
- [ ] Éviter l'injection HTML et tenir compte du clavier.

## 1. Le DOM est une représentation de la page

HTML :

```html
<button id="ajouter" type="button">+1 point</button>
<p id="score" aria-live="polite">Score : 0</p>
<script src="main.js" defer></script>
```

JavaScript (`main.js`) :

```js
let score = 0;
const bouton = document.querySelector('#ajouter');
const zone = document.querySelector('#score');

bouton.addEventListener('click', () => {
  score += 1;
  zone.textContent = `Score : ${score}`;
});
```

`querySelector` peut renvoyer `null` si le sélecteur est incorrect. `defer` assure que le DOM HTML est prêt lorsque le script classique externe s'exécute.

## 2. `textContent` plutôt que `innerHTML`

```js
const messageUtilisateur = '<img src=x onerror=alert(1)>';
zone.textContent = messageUtilisateur; // texte affiché, non interprété en HTML
// zone.innerHTML = messageUtilisateur; // dangereux avec des données non fiables
```

`innerHTML` peut être utile avec des fragments HTML **entièrement maîtrisés**, mais jamais en insérant directement une entrée utilisateur non fiable. Si tu dois produire des éléments dynamiques, utilise `createElement` / `textContent`.

## 3. Événements et propagation

```js
const liste = document.querySelector('#liste');

liste.addEventListener('click', (event) => {
  const bouton = event.target.closest('button[data-id]');
  if (!bouton || !liste.contains(bouton)) return;
  console.log('ID sélectionné :', bouton.dataset.id);
});
```

Un écouteur sur un conteneur peut gérer plusieurs boutons qui seront ajoutés plus tard : **délégation d'événements**. `event.target` est l'élément d'origine ; `event.currentTarget` est celui qui porte l'écouteur.

## 4. Formulaire avec retour accessible

```html
<form id="creation">
  <label for="pseudo">Pseudo</label>
  <input id="pseudo" name="pseudo" required minlength="3" maxlength="20">
  <button type="submit">Créer un joueur</button>
</form>
<p id="retour" role="status" aria-live="polite"></p>
<script src="form.js" defer></script>
```

```js
const formulaire = document.querySelector('#creation');
const retour = document.querySelector('#retour');

formulaire.addEventListener('submit', (event) => {
  event.preventDefault(); // pas de rechargement automatique
  const pseudo = formulaire.elements.namedItem('pseudo').value.trim();
  if (pseudo.length < 3 || pseudo.length > 20) {
    retour.textContent = 'Entre 3 et 20 caractères.';
    return;
  }
  retour.textContent = `Bienvenue ${pseudo} !`;
});
```

Vérifier la longueur JavaScript avec `.length` compte les unités UTF-16 et non nécessairement les caractères visibles. Ici, c'est suffisant pour comprendre l'API ; une politique de noms réels peut nécessiter une validation plus fine.

## 5. Accessibilité : tests concrets

- Un `<button>` natif est utilisable au **clavier** ; évite un simple `<div onclick=...>`.
- Un `<label>` lié à l'input permet de comprendre le champ.
- Le contraste, l'ordre de tabulation, les messages d'erreur et la navigation sans souris comptent.
- `aria-live` peut annoncer un score ou un statut à une technologie d'assistance ; évite les annonces trop fréquentes.

Le sujet propose un module d'accessibilité WCAG 2.1 AA en option, tandis qu'un frontend **responsive et accessible** est déjà exigé pour la partie technique obligatoire.

## 6. Atelier : liste de joueurs

```js
function creerElementJoueur(joueur) {
  const li = document.createElement('li');
  li.textContent = `${joueur.pseudo} : ${joueur.score}`;
  return li;
}

const liste = document.querySelector('#joueurs');
const joueurs = [{ pseudo: 'Ada', score: 2 }, { pseudo: 'Lin', score: 3 }];
for (const joueur of joueurs) liste.append(creerElementJoueur(joueur));
```

Le HTML doit contenir `<ul id="joueurs"></ul>` : voir l'exemple complet [[Annexe-Ateliers-pratiques]].

## Exercices

1. Crée un bouton « Réinitialiser » qui ramène le score de la page à 0.
2. Ajoute un formulaire avec un champ `points`, refuse les valeurs négatives et les décimaux.
3. Construis une liste `<li>` à partir d'un tableau de noms non fiables **sans `innerHTML`**.
4. Test manuel : utilise la page uniquement avec Tab, Entrée et Espace.

## Questions
- Pourquoi `preventDefault` sur un formulaire ?
- Quelle différence entre `textContent` et `innerHTML` ?
- Pourquoi la validation côté navigateur ne suffit-elle pas ?

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 07]].


## Navigation

← [[06-Objets-JSON-Map-et-Set|Leçon précédente]] · [[00-Accueil|Parcours]] · [[08-Asynchronisme-Promises-et-fetch|Leçon suivante]]
