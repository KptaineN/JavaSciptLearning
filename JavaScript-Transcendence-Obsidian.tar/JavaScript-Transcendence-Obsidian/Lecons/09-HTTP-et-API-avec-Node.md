---
type: lecon
cours: JavaScript - ft_transcendence
numero: 09
niveau: Intermédiaire
statut: a-faire
tags: [javascript, backend]
---

# 09 — HTTP, API REST et Node.js

> [!abstract] Mission
> Comprendre la communication navigateur ↔ serveur et créer une petite API sans framework. **120 min**.

## Objectifs
- [ ] Définir route, méthode HTTP, statut et JSON.
- [ ] Distinguer frontend, backend et base de données.
- [ ] Écrire un serveur HTTP minimal avec Node.js.
- [ ] Valider côté serveur et tester avec `curl`.

## 1. Une API HTTP, c'est un contrat

| Méthode | Route | Idée | Statut possible |
|---|---|---|---|
| GET | `/api/joueurs` | lire une collection | 200 |
| GET | `/api/joueurs/42` | lire une ressource | 200 ou 404 |
| POST | `/api/joueurs` | créer une ressource | 201 ou 400 |
| PUT | `/api/joueurs/42` | remplacer une ressource | 200/204 ou 404 |
| DELETE | `/api/joueurs/42` | supprimer | 204 ou 404 |

REST est un ensemble de principes architecturaux : la table montre des **conventions courantes**, pas une garantie sur toutes les API. Un backend doit gérer aussi l'authentification, l'autorisation, les validations et les accès concurrents.

## 2. Exemple autonome avec `node:http`

Crée `serveur.mjs` puis lance `node serveur.mjs`. Aucune dépendance npm nécessaire.

```js
import http from 'node:http';

const joueurs = [{ id: 1, pseudo: 'Ada' }];

const serveur = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  if (req.method === 'GET' && url.pathname === '/api/joueurs') {
    res.writeHead(200);
    res.end(JSON.stringify(joueurs));
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/joueurs') {
    let corps = '';
    try {
      for await (const bloc of req) {
        corps += bloc;
        if (corps.length > 4096) throw new Error('Corps trop grand');
      }
      const entree = JSON.parse(corps);
      if (typeof entree.pseudo !== 'string' ||
          entree.pseudo.trim().length < 3 ||
          entree.pseudo.length > 20) {
        res.writeHead(400);
        res.end(JSON.stringify({ erreur: 'Pseudo invalide' }));
        return;
      }
      const joueur = { id: joueurs.length + 1, pseudo: entree.pseudo.trim() };
      joueurs.push(joueur);
      res.writeHead(201);
      res.end(JSON.stringify(joueur));
    } catch {
      res.writeHead(400);
      res.end(JSON.stringify({ erreur: 'Requête invalide' }));
    }
    return;
  }
  res.writeHead(404);
  res.end(JSON.stringify({ erreur: 'Route absente' }));
});

serveur.listen(3000, '127.0.0.1', () => {
  console.log('API locale : http://127.0.0.1:3000');
});
```

> [!warning] Limites volontaires du serveur d'apprentissage
> Données **en mémoire**, ID simplifié, pas d'authentification, taille mesurée en caractères et non en octets, pas de gestion complète des déconnexions / erreurs de flux, pas de base de données. Ne pas déployer tel quel sur Internet. L'exemple exécutable renforcé de l'annexe limite les octets lus.

## 3. Tester avec `curl`

```bash
curl -i http://127.0.0.1:3000/api/joueurs
curl -i -X POST http://127.0.0.1:3000/api/joueurs \
  -H 'Content-Type: application/json' \
  -d '{"pseudo":"Lin"}'
curl -i -X POST http://127.0.0.1:3000/api/joueurs \
  -H 'Content-Type: application/json' \
  -d '{"pseudo":"x"}'
```

Résultat attendu : GET 200, création 201, entrée invalide 400. Teste ensuite un chemin inconnu → 404.

## 4. Appel depuis le navigateur

```js
async function creerJoueur(pseudo) {
  const reponse = await fetch('/api/joueurs', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ pseudo }),
  });
  const donnees = await reponse.json();
  if (!reponse.ok) throw new Error(donnees.erreur ?? 'Erreur API');
  return donnees;
}
```

Le chemin relatif fonctionne lorsque **le site et l'API ont la même origine** ou lorsqu'un proxy de développement redirige `/api`. Si tu sers le HTML par un autre port, tu dois aussi comprendre la politique **CORS** ; ce n'est pas un mécanisme d'authentification.

## 5. HTTPS, secrets et SQL : préparer le vrai projet

Dans le sujet v21.2, toute connexion au backend depuis un navigateur/script/API externe doit utiliser **HTTPS**. L'HTTP local ci-dessus est strictement un exercice. Pour un vrai déploiement : TLS via reverse proxy ou serveur approprié ; variables sensibles dans `.env` non versionné + `.env.example` ; mots de passe hachés avec un algorithme adapté ; requêtes SQL paramétrées ; accès autorisés côté backend. La base de données est requise par le projet, mais ce petit exercice n'en utilise pas.

## Exercices

1. Ajoute `GET /api/sante` → `{ "status": "ok" }`.
2. Teste le POST avec un JSON malformé, puis un pseudo trop court : compare les réponses.
3. Explique pourquoi ne jamais faire confiance à une validation exécutée uniquement dans le navigateur.
4. Dessine le trajet de `fetch()` jusqu'à la réponse affichée par le DOM.

## Questions
- Différence entre 400, 401, 403, 404 et 500 ?
- Pourquoi une requête POST n'est pas automatiquement une création réussie ?
- Pourquoi une base est-elle nécessaire dans l'application finale ?

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 09]].


## Navigation

← [[08-Asynchronisme-Promises-et-fetch|Leçon précédente]] · [[00-Accueil|Parcours]] · [[10-Modules-architecture-et-etat|Leçon suivante]]
