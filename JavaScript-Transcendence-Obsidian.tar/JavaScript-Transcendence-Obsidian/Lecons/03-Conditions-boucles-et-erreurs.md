---
type: lecon
cours: JavaScript - ft_transcendence
numero: 03
niveau: Débutant
statut: a-faire
tags: [javascript, controle]
---

# 03 — Conditions, boucles et erreurs

> [!abstract] Mission
> Traduire des règles métier en branches lisibles, parcourir des données et gérer les erreurs. **75 min**.

## Objectifs
- [ ] Utiliser `if`, `switch`, `while`, `for...of`.
- [ ] Différencier `for...of` et `for...in`.
- [ ] Gérer `throw`, `try/catch/finally`.
- [ ] Écrire des gardes (*early returns*) lisibles.

## 1. Brancher sur les règles d'un jeu

```js
function resultatPartie(scoreA, scoreB) {
  if (scoreA > scoreB) return 'A gagne';
  if (scoreB > scoreA) return 'B gagne';
  return 'Égalité';
}
```

Les `return` anticipés évitent les pyramides de `else`. C'est particulièrement utile pour valider des entrées.

```js
function autoriserPartie(joueur) {
  if (joueur == null) return false;
  if (!joueur.connecte) return false;
  if (joueur.suspendu) return false;
  return true;
}
```

## 2. `switch` pour les événements

```js
function traiterAction(action) {
  switch (action.type) {
    case 'MOVE':
      return `Déplacement : ${action.direction}`;
    case 'QUIT':
      return 'Joueur déconnecté';
    default:
      return 'Action inconnue';
  }
}
```

`break` est nécessaire dans les branches qui ne font pas `return`, sinon il y a *fallthrough*. `switch` compare avec une égalité stricte.

## 3. Itération

```js
const scores = [4, 8, 2];
let somme = 0;
for (const score of scores) somme += score;
console.log(somme); // 14

let index = 0;
while (index < scores.length) {
  console.log(index, scores[index]);
  index += 1;
}
```

`for...of` parcourt **les valeurs** d'un itérable ; `for...in` parcourt les **clés énumérables**, à éviter pour parcourir les éléments d'un tableau. Les méthodes `.map()`, `.filter()` et `.reduce()` seront vues en leçon 05.

## 4. Séparer erreur et valeur normale

```js
function calculerRatio(victoires, parties) {
  if (!Number.isInteger(parties) || parties <= 0) {
    throw new RangeError('parties doit être un entier positif');
  }
  return victoires / parties;
}

try {
  console.log(calculerRatio(3, 0));
} catch (erreur) {
  console.error(erreur.message);
} finally {
  console.log('Fin du calcul');
}
```

`throw` interrompt le flux normal ; `catch` doit gérer l'erreur, pas simplement la masquer. Dans une API, tu distingueras plus tard erreurs de validation (réponse 400) et bugs imprévus (réponse 500).

## 5. Garde contre les boucles infinies

```js
let tentatives = 0;
while (tentatives < 3) {
  console.log(`Tentative ${tentatives + 1}`);
  tentatives++;
}
```

Dans le navigateur, une boucle synchrone infinie bloque l'interface et peut empêcher l'actualisation de la page. La boucle événementielle sera abordée en leçon 08.

## 6. Atelier : classement basique

```js
function afficherClassement(joueurs) {
  for (const joueur of joueurs) {
    if (!joueur.actif) continue;
    console.log(`${joueur.pseudo} : ${joueur.points}`);
  }
}

afficherClassement([
  { pseudo: 'Ada', points: 6, actif: true },
  { pseudo: 'Lin', points: 0, actif: false },
]);
```

L'exemple illustre `continue`. Si tu préfères éviter ce mot-clé, remplace la condition par `if (joueur.actif) { console.log(...) }`.

## Exercices

1. Crée `mention(score)` : `insuffisant` sous 10, `correct` de 10 à 14 exclus, `bien` à partir de 14 (sur 20).
2. Avec `while`, trouve le premier entier positif dont le carré est supérieur à 100.
3. Crée `division(a, b)` qui lance une `RangeError` si `b === 0` ; intercepte-la sans faire disparaître les autres erreurs.

## Vérification
- Quand préférer `for...of` à `for...in` ?
- Quel est le rôle de `finally` ?
- Pourquoi éviter `catch (e) {}` vide ?

Corrigés : [[Annexe-Corriges-des-exercices#Leçon 03]].


## Navigation

← [[02-Variables-types-et-conversions|Leçon précédente]] · [[00-Accueil|Parcours]] · [[04-Fonctions-portee-et-closures|Leçon suivante]]
