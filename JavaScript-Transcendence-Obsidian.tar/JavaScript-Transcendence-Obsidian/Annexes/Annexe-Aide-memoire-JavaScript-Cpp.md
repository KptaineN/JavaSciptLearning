# Annexe — Aide-mémoire JavaScript pour développeur C / C++

## Comparaisons utiles

| En C/C++ | En JavaScript | Attention |
|---|---|---|
| `int score = 0;` | `let score = 0;` | type dynamique |
| `const int x = 1;` | `const x = 1;` | interdit la réassignation, **pas** les mutations internes |
| `printf("%d", x)` | `console.log(x)` | console de debug |
| `std::vector<int>` | `[1, 2, 3]` | tableaux dynamiques et hétérogènes |
| `std::map` | `new Map()` | clés arbitraires |
| `std::set` | `new Set()` | éléments uniques |
| `struct Joueur` | `{ pseudo: 'Ada', score: 0 }` | propriétés dynamiques |
| `nullptr` | `null` | `undefined` existe aussi |
| exceptions C++ | `throw`, `try/catch` | pas d'exceptions typées au `catch` |
| lambda | `(n) => n * 2` | `this` lexical pour une fléchée |
| `.h` + `.cpp` | `export/import` | résolution des modules |
| threads/processus | Promise + event loop | asynchrone ≠ multithreading |

## Syntaxe quotidienne

```js
const max = 10;
let score = 0;
if (score < max) score++;

for (const element of [1, 2, 3]) console.log(element);

const addition = (a, b) => a + b;
const pseudo = 'Ada';
console.log(`${pseudo} a ${addition(2, 3)} points`);

const joueur = { pseudo, score };
const { pseudo: nom } = joueur;
const copie = { ...joueur, score: 9 };
```

## Méthodes à mémoriser

```js
[1, 2, 3].map((x) => x * 2);          // [2,4,6]
[1, 2, 3].filter((x) => x >= 2);     // [2,3]
[1, 2, 3].find((x) => x > 2);        // 3
[1, 2, 3].some((x) => x > 2);        // true
[1, 2, 3].every((x) => x > 0);       // true
[1, 2, 3].reduce((sum, x) => sum + x, 0); // 6
```

## Les sept erreurs récurrentes

1. `==` au lieu de `===` pour une comparaison sans coercition.
2. `||` au lieu de `??` pour une valeur par défaut où 0 est valide.
3. Croire que `const` empêche de modifier un objet.
4. Confondre `map` et `forEach` (`forEach` ne construit pas un nouveau tableau de résultats).
5. Croire que `fetch` rejette sur tous les statuts HTTP d'erreur.
6. Modifier le tableau d'origine avec `.sort()` sans le vouloir.
7. Croire que le client navigateur fait autorité pour les comptes et les scores.

## Petits diagnostics à savoir faire

```js
console.log(typeof null);       // 'object' (historique)
console.log([] === []);          // false (identités différentes)
console.log(0 || 7);             // 7
console.log(0 ?? 7);             // 0
console.log(Number('abc'));     // NaN
console.log(Number.isNaN(NaN));  // true
```

## Checklist de code relisible

- [ ] Noms de fonctions verbaux : `calculerScore`, `chargerJoueurs`.
- [ ] Une responsabilité par fonction, séparation des effets et du calcul.
- [ ] Entrées vérifiées, erreurs significatives, résultats testables.
- [ ] Pas de valeur sensible dans la console ou le dépôt Git.
- [ ] Pas de manipulation `innerHTML` avec entrée non fiable.
- [ ] Chaque appel réseau gère les erreurs et l'état de chargement.
- [ ] Un autre membre de l'équipe peut expliquer le code sans aide.
