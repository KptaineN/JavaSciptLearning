# Annexe — JavaScript face au sujet ft_transcendence v21.2

> [!info] Source de référence
> Cette annexe distingue **ce que le PDF fourni exige**, **ce que les modules peuvent ajouter**, et **nos choix pédagogiques**. Référence : `en.subject.pdf`, *ft_transcendence*, **version 21.2**. La formulation du PDF fait toujours autorité pour l'évaluation.

## Partie obligatoire du sujet (chapitre III, pages imprimées 7–9)

- Application **Web** avec **frontend, backend et base de données**.
- Git utilisé avec commits explicites et contribution de chaque membre.
- Déploiement avec **Docker, Podman ou équivalent**, démarrage **en une commande**.
- Compatibilité avec la dernière version stable de **Google Chrome**.
- **Aucun avertissement ni erreur JavaScript** dans la console du navigateur.
- Pages **Privacy Policy** et **Terms of Service** accessibles, pertinentes et non vides.
- Prise en charge **de plusieurs utilisateurs simultanément**, actions concurrentes cohérentes.
- Frontend responsive et accessible ; solution de style/CSS au choix.
- Variables sensibles dans `.env` ignoré par Git ; fichier `.env.example`.
- Schéma de base de données clair et relations définies.
- Gestion utilisateur de base, **inscription + connexion** avec email/mot de passe et sécurité adéquate.
- **Validation des formulaires et entrées frontend ET backend**.
- **HTTPS** pour toute connexion externe au backend (navigateur, script ou API).

> [!warning] Pourquoi JavaScript ?
> Le sujet ne prescrit pas nécessairement JavaScript pour **tous** les composants. Il décrit les attentes d'une application Web, avec des technologies laissées au choix de l'équipe. Les exemples React / Express / Fastify / Node.js sont des choix plausibles, non des exigences universelles.

## Modules en lien direct avec le cours (chapitre IV, pages imprimées 10–20)

| Leçons | Module possible | Ce que le cours prépare |
|---|---|---|
| 07, 10 | Framework frontend (Minor) | comprendre DOM et composants avant React/Vue |
| 09, 10 | Framework backend (Minor) | contrats HTTP et séparation métier |
| 08, 11 | Fonctions temps réel (Major) | WebSocket, diffusion, déconnexion |
| 07, 11 | Interactions utilisateurs (Major) | base d'une interface de chat / profil |
| 09, 12 | API publique (Major) | routes, validations, erreurs ; il reste clés, limites, doc |
| 07 | Accessibilité WCAG 2.1 AA (Major) | notions initiales, pas une certification complète |
| 11 | Jeu Web / jeu distant (Majors) | synchronisation, état autoritaire, latence |
| 12 | Recherche / tests et robustesse | qualité transversale, non module autonome |

Le sujet exige **14 points** pour le projet : **Major = 2 points**, **Minor = 1 point**. Certains modules possèdent des **dépendances** : par exemple, les statistiques de partie nécessitent un jeu implémenté ; le chat avancé nécessite le chat de base. Un jeu Pong est **un exemple**, pas le produit imposé.

## README et équipe (chapitres II et VI)

Le sujet demande un travail d'équipe de **4–5 personnes**, avec des rôles clairement définis. Le `README.md` final doit être **en anglais** et expliquer : description, instructions de lancement, ressources / usage de l'IA, équipe, gestion, stack, schéma DB, fonctionnalités, modules/points et contributions individuelles.

Le cours ici est en français pour apprendre, mais le **README final du projet** a une contrainte de langue distincte.

## Où commence notre initiative pédagogique ?

Les choix suivants ne sont **pas des instructions du PDF** :

- Suivre 12 leçons JavaScript dans cet ordre.
- Choisir Node.js et `ws` comme outils d'entraînement.
- Faire un « tableau de scores » en fil rouge.
- Utiliser Obsidian, `node:test`, curl, Robot Framework ou Playwright pour l'apprentissage.
- Employer un modèle serveur « autoritaire » ; c'est une recommandation technique de conception pour un jeu, pas un module imposé à toute application.

## Vérification avant les vrais choix techniques

- [ ] Les membres ont convenu d'une idée de produit et des utilisateurs cibles.
- [ ] Les 14 points prévus proviennent de modules cohérents, avec leurs prérequis.
- [ ] La stack est justifiée au regard des compétences et du temps de l'équipe.
- [ ] L'architecture précise les flux multi-utilisateurs, la validation et les accès.
- [ ] Le plan de tests couvre les obligations transversales.

Retour : [[00-Accueil]].
