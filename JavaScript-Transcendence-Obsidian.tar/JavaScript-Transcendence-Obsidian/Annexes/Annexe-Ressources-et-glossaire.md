# Annexe — Ressources complémentaires et glossaire

## Documentation de référence (langage / navigateur)

- [MDN — JavaScript Guide](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide) : un guide structuré pour le langage.
- [MDN — JavaScript Reference](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference) : consulter une syntaxe, une fonction ou un objet précisément.
- [MDN — DOM](https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model) : structure et manipulation des pages.
- [MDN — Fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API) : requêtes HTTP côté navigateur.
- [MDN — WebSocket API](https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API) : événements et connexion WebSocket côté navigateur.
- [MDN — Learn web development](https://developer.mozilla.org/en-US/docs/Learn_web_development) : progression complète HTML, CSS et JS.
- [JavaScript.info](https://javascript.info/) : cours détaillé avec nombreux exercices.
- [Eloquent JavaScript](https://eloquentjavascript.net/) : ouvrage en ligne, bon complément pour les problèmes algorithmiques.

## Backend et qualité

- [Node.js — Learn](https://nodejs.org/en/learn) : architecture et APIs de Node.
- [Node.js — Test runner](https://nodejs.org/api/test.html) : référence de `node:test`.
- [Node.js — HTTP](https://nodejs.org/api/http.html) : serveur HTTP natif.
- [ws sur npm](https://www.npmjs.com/package/ws) : bibliothèque WebSocket côté serveur Node.
- [OWASP — Input Validation](https://cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html) : limites de validation et contrôles serveur.
- [OWASP — XSS Prevention](https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html) : bonnes pratiques d'affichage de données non fiables.
- [OWASP — Password Storage](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html) : stockage correct des mots de passe.
- [Playwright](https://playwright.dev/docs/intro) : automatisation de navigateurs.
- [Robot Framework](https://robotframework.org/) : framework de tests générique et extensible.
- [Postman Learning Center](https://learning.postman.com/) : conception/test d'API.
- [k6](https://grafana.com/docs/k6/latest/) : tests de charge.

## Comment utiliser ces ressources ?

- Tu ne comprends pas un mot-clé : commence par **leçon → MDN Guide**.
- Une fonction précise ne marche pas : cherche **MDN Reference** et regarde compatibilité / exceptions / exemples.
- Un comportement async te surprend : relis la leçon 08, puis [MDN — Event loop](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Execution_model).
- Une API échoue : observe **Network**, puis [Node HTTP](https://nodejs.org/api/http.html).
- Une vulnérabilité ou une validation ambiguë : consulte **OWASP**.

## Glossaire à connaître

| Terme | Définition courte |
|---|---|
| Runtime | environnement qui exécute le JavaScript (ex. navigateur, Node) |
| ECMAScript | spécification du langage JavaScript |
| DOM | représentation structurée d'un document HTML accessible en JS |
| Callback | fonction transmise pour être appelée plus tard/ailleurs |
| Closure | fonction qui retient l'accès aux variables de son environnement lexical |
| Hoisting | comportement des déclarations lors de la préparation d'une portée |
| Mutation | modification d'un tableau ou objet existant |
| Immutabilité | stratégie consistant à produire de nouvelles valeurs plutôt que muter |
| Promise | objet représentant le résultat futur d'une opération |
| Event loop | mécanisme de coordination des tâches et microtâches |
| Microtâche | tâche prioritaire entre étapes de la boucle, ex. réaction Promise |
| `fetch` | API pour effectuer des requêtes réseau, renvoie une Promise |
| HTTP | protocole requête/réponse utilisé par les API Web |
| HTTPS | HTTP sur TLS pour chiffrer et authentifier la connexion |
| JSON | format texte d'échange de données |
| REST | style d'architecture pour concevoir des interfaces réseau |
| CORS | politique navigateur gouvernant certaines requêtes inter-origines |
| WebSocket | connexion bidirectionnelle persistante client/serveur |
| WSS | WebSocket protégé par TLS |
| XSS | injection de script ou contenu actif non fiable dans un contexte web |
| Injection SQL | exploitation d'une requête SQL construite avec des entrées non fiables |
| Authentification | vérifier qui est l'utilisateur |
| Autorisation | déterminer ce que cet utilisateur peut faire |
| Test unitaire | vérifie une unité de logique isolée |
| Test d'intégration | vérifie plusieurs composants ensemble |
| E2E | parcourt une fonctionnalité de bout en bout |
| Backpressure | gestion d'un consommateur plus lent que le producteur |
| Source de vérité | composant dont les données sont considérées comme autoritatives |

## Ressources à ne pas confondre avec le sujet 42

Ces liens expliquent **le JavaScript et les technologies connexes** ; pour les obligations exactes d'évaluation, reporte-toi toujours au PDF `ft_transcendence` fourni et à [[Annexe-Sujet-ft-transcendence]].
