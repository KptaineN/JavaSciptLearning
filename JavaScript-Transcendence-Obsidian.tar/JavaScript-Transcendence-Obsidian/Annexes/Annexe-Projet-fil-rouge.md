# Annexe — Projet fil rouge : tableau de scores multi-utilisateur

> [!note] Positionnement
> Ce mini-projet est une **préparation** aux problématiques d'une application collaborative ou d'un jeu, sans prétendre satisfaire à lui seul ft_transcendence. Le projet officiel est libre : **Pong n'est pas obligatoire**.

## Cahier des charges pédagogique

**MVP local** : afficher une liste de joueurs avec leur score, permettre d'ajouter un joueur, modifier un score dans une interface, échanger les données avec une API locale, puis diffuser un événement aux clients connectés.

**Hors périmètre de l'atelier** : vraie authentification, base de données, HTTPS, Docker, reconnexion fiable, sécurité production. Ils restent indispensables ou pertinents **pour le vrai projet selon le sujet et ses modules**.

## Architecture progressive

```text
Étape 1 : tableau statique JS        (leçons 01–06)
Étape 2 : rendu DOM + formulaire      (leçon 07)
Étape 3 : chargement asynchrone       (leçon 08)
Étape 4 : API locale                 (leçon 09)
Étape 5 : modules métier / api / UI   (leçon 10)
Étape 6 : notifications WebSocket     (leçon 11)
Étape 7 : tests / sécurité            (leçon 12)
```

## User stories

- **US-01** : en tant que visiteur, je vois le classement des joueurs.
- **US-02** : en tant qu'organisateur, je crée un joueur avec un pseudo valide.
- **US-03** : en tant qu'organisateur, je modifie un score et reçois une confirmation.
- **US-04** : en tant que visiteur connecté, je vois la mise à jour d'un score effectué par un autre client.
- **US-05** : en tant qu'utilisateur clavier, je navigue sans souris.
- **US-06** : en tant que testeur, je peux vérifier les cas normaux et invalides.

Les rôles « visiteur » et « organisateur » sont **à implémenter** dans une véritable version multi-utilisateur ; ils sont ici des rôles fonctionnels imaginés pour les tests, pas des permissions déjà sécurisées.

## Modèle de données proposé

```js
const joueur = {
  id: 1,
  pseudo: 'Ada',
  score: 0,
  dateCreation: '2026-10-26T10:00:00.000Z',
};
```

En vraie base relationnelle, définir `id` comme clé primaire, `pseudo` avec contraintes de longueur/unicité si pertinent, `score` borné et une stratégie de mise à jour atomique.

## Contrat HTTP cible (exercice de conception)

| Route | Méthode | Entrée | Réponse |
|---|---|---|---|
| `/api/joueurs` | GET | rien | tableau JSON / 200 |
| `/api/joueurs` | POST | `{ pseudo }` | nouveau joueur / 201 |
| `/api/joueurs/:id` | GET | id | joueur / 200 ou 404 |
| `/api/joueurs/:id/score` | PATCH | `{ gain }` | nouveau score / 200 |

**Important :** ces routes forment un **objectif de mini-projet**, pas une liste d'API déjà implémentées dans les exemples fournis. `Exemples/api.mjs` implémente uniquement GET collection et POST création.

## Événements WebSocket proposés

```json
{"type":"score.updated","joueurId":1,"score":15}
```

Le message représente un événement envoyé par **le serveur après validation**. N'accepte pas un score final envoyé par n'importe quel client sans contrôle ; un client doit communiquer une intention autorisée (par exemple `{ "type": "score.add", "gain": 1 }`).

## Découpage en 7 jalons

1. [ ] **Données** : tableau de 3 joueurs, top 3 avec tri non destructif.
2. [ ] **DOM** : liste accessible avec chargement et message vide.
3. [ ] **Formulaire** : saisies valides et invalides, `textContent`.
4. [ ] **API** : GET + POST testés manuellement, statuts cohérents.
5. [ ] **Modules** : `domain/`, `api/`, `ui/` et tests métier.
6. [ ] **Temps réel** : 2 onglets synchronisés, déconnexion gérée.
7. [ ] **Qualité** : tests unitaires, API, E2E, clavier, audit console.

## Définition de « terminé » pour une fonctionnalité

- [ ] Les cas normaux fonctionnent.
- [ ] Les entrées invalides sont rejetées côté serveur.
- [ ] Un autre membre peut relire et expliquer l'implémentation.
- [ ] Un test reproductible couvre un bug important.
- [ ] Pas de données sensibles exposées, pas d'erreur JS non traitée.
- [ ] Les limites connues sont documentées.

## Aller plus loin avec ft_transcendence

La version finale du projet à 42 exige notamment une **base de données**, une application Web complète, une gestion d'utilisateurs avec **inscription/connexion sécurisées**, **HTTPS**, un frontend responsive/accessible, la prise en charge multi-utilisateur et un déploiement en **une commande** via conteneurisation. Les modules sélectionnés par l'équipe doivent totaliser **14 points** (Major = 2, Minor = 1). Voir [[Annexe-Sujet-ft-transcendence]].
