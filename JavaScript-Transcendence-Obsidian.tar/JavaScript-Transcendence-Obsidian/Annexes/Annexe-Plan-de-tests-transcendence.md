# Annexe — Plan de tests pour ft_transcendence (version préparatoire)

## Distinguer exigence, choix et hypothèse

- **Exigences du sujet v21.2** : web frontend/backend/DB, plusieurs utilisateurs, Chrome stable, aucune erreur/warning JS, authentification email/mot de passe, entrées validées sur frontend et backend, HTTPS, pages légales, containerisation en une commande.
- **Selon les modules choisis** : jeu, chat, WebSockets, OAuth, WCAG 2.1 AA, support navigateurs supplémentaires, gamification, etc.
- **Hypothèse de travail** : une application de classement/jeu, utilisée ici uniquement pour construire une bibliothèque de tests.

## Axes et priorités

| Domaine | Risque principal | Type de test | Priorité |
|---|---|---|---|
| Authentification | usurpation / fuite de session | API + sécurité | P0 |
| Autorisation | modifier les données d'autrui | API | P0 |
| Validation | entrée malformée / XSS | unitaire + API + UI | P0 |
| Concurrence | doublon, conflit d'état | intégration + charge | P0 |
| HTTPS | requêtes externes non chiffrées | configuration + réseau | P0 |
| Console JS | erreur non traitée | E2E + manuel | P0 |
| Responsive | interface inutilisable mobile | manuel + E2E | P1 |
| Pages légales | lien absent / contenu vide | E2E + manuel | P0 |
| Temps réel (si choisi) | messages perdus / clients lents | intégration + charge | P1 |

## Jeux de cas prêts à copier dans Obsidian

### AUTH-01 — Mot de passe incorrect

- **Précondition** : compte existant.
- **Action** : saisir email valide et mauvais mot de passe.
- **Attendu** : échec clair, aucune session ouverte, aucune donnée confidentielle retournée.
- **Automatisation** : API (Postman/Robot), E2E possible.

### AUTH-02 — Autorisation inter-utilisateurs

- **Précondition** : comptes A et B, sessions distinctes.
- **Action** : A tente de modifier une ressource dont B est propriétaire.
- **Attendu** : refus approprié, aucune modification de la ressource de B.
- **Automatisation** : test API.

### CONC-01 — Créations simultanées

- **Précondition** : serveur démarré, deux clients distincts.
- **Action** : poster simultanément deux requêtes de création distinctes.
- **Attendu** : deux ressources persistées sans collision et avec identifiants uniques.
- **Automatisation** : test d'intégration avec deux requêtes en parallèle.

### WEB-01 — Console propre

- **Précondition** : dernière version de l'application, Chrome stable.
- **Action** : ouvrir accueil, naviguer, remplir des formulaires, déclencher les erreurs prévues.
- **Attendu** : aucune erreur ou avertissement **JavaScript** dans la console, les erreurs métier restent gérées.
- **Automatisation** : E2E + examen manuel.

### ACCESS-01 — Navigation clavier

- **Action** : débrancher la souris et parcourir les écrans au clavier.
- **Attendu** : focus visible, actions atteignables et compréhensibles.
- **Type** : manuel ; approfondir si module accessibilité sélectionné.

### REAL-01 — Déconnexion (si fonctionnalités temps réel)

- **Action** : connecter deux clients, fermer l'un en pleine session.
- **Attendu** : l'autre reste réactif ; état de présence cohérent ; ressources libérées.
- **Type** : intégration/WebSocket.

### REAL-02 — Client lent (si temps réel)

- **Action** : un client cesse de lire, un autre échange activement.
- **Attendu** : l'application reste réactive suivant les limites et la politique de backpressure définies ; mémoire bornée.
- **Type** : charge/robustesse.

## Automatiser progressivement

1. **Avant le frontend** : cas métier exécutables (`node:test`).
2. **Backend en place** : tests HTTP avec `curl`/Postman ; vérification des statuts et corps.
3. **UI utilisable** : Robot Framework ou Playwright pour les parcours utilisateurs.
4. **Maturité** : tests multi-clients, charge et résilience (k6/JMeter selon l'architecture).

> [!tip] Pour ta préparation
> Un cas de test dans Obsidian comporte ID, préconditions, étapes, données, attendu, obtenu, statut, preuve et type (manuel / automatisable). Duplique [[Template-Cas-de-test]] plutôt que créer une note informelle à chaque nouveau bug.

## Matrice de traçabilité simplifiée

| Exigence | Test(s) | Statut initial |
|---|---|---|
| Authentification sécurisée | AUTH-01 | à concevoir |
| Autorisations | AUTH-02 | à concevoir |
| Multi-utilisateur | CONC-01 | à concevoir |
| Pas d'erreur JS | WEB-01 | à concevoir |
| Responsive / accessible | ACCESS-01 | à concevoir |
| Fonctions temps réel si retenues | REAL-01, REAL-02 | optionnel |

Les scénarios devront être ajustés aux **modules effectivement retenus par l'équipe** avant d'être considérés comme des critères d'acceptation définitifs.
