# Annexe — Corrigés des exercices des 12 leçons

> [!warning] Usage recommandé
> Termine d'abord un exercice dans ta propre note, exécute-le, puis compare. Les corrigés montrent **une** solution lisible, pas la seule solution correcte.

## Leçon 01

**1. Premier script** — `presentation.js` :

```js
const prenom = 'Ada';
const ancien = 'C++';
const nouveau = 'JavaScript';
console.log(`${prenom} connaît ${ancien} et apprend ${nouveau}.`);
```

**2. Modifier le DOM** — `index.html` contient `<p id="etat">En attente</p>` et `<script src="main.js" defer></script>`. Dans `main.js` :

```js
const etat = document.querySelector('#etat');
etat.textContent = 'Prêt !';
```

**3. Erreur volontaire** — `console.log(inconnu)` génère une **ReferenceError** si la variable n'est pas déclarée. Le navigateur ou Node indique normalement le fichier et la ligne.

## Leçon 02

**1. Afficher un score y compris 0** :

```js
function afficherScore(pseudo, score = 0) {
  console.log(`${pseudo} a ${score ?? 0} point(s)`);
}
afficherScore('Ada', 0); // Ada a 0 point(s)
```

Le paramètre `score = 0` couvre `undefined`, et `??` couvre également `null` si c'est la politique souhaitée.

**2. Prédictions** : `typeof null` → `'object'` ; `Boolean([])` → `true` ; `'5' + 2` → `'52'` ; `'5' - 2` → `3` ; `0 ?? 10` → `0`.

**3. Valider un âge** :

```js
function validerAge(texte) {
  if (typeof texte !== 'string' || !/^\d+$/.test(texte)) return null;
  const n = Number(texte);
  return Number.isInteger(n) && n >= 0 && n <= 120 ? n : null;
}
```

## Leçon 03

**1. Mention** :

```js
function mention(score) {
  if (typeof score !== 'number' || !Number.isFinite(score) || score < 0 || score > 20) {
    throw new RangeError('Score sur 20 attendu');
  }
  if (score < 10) return 'insuffisant';
  if (score < 14) return 'correct';
  return 'bien';
}
```

**2. Boucle** :

```js
let n = 1;
while (n * n <= 100) n++;
console.log(n); // 11
```

**3. Division** :

```js
function division(a, b) {
  if (b === 0) throw new RangeError('Division par zéro');
  return a / b;
}
try {
  console.log(division(4, 0));
} catch (erreur) {
  if (!(erreur instanceof RangeError)) throw erreur;
  console.error(erreur.message);
}
```

## Leçon 04

**1. Fabrique de fonction** :

```js
function creerMultiplicateur(facteur) {
  return (valeur) => valeur * facteur;
}
const doubler = creerMultiplicateur(2);
console.log(doubler(6)); // 12
```

**2. Score privé** :

```js
function creerScore(initial = 0) {
  let score = initial;
  return {
    ajouter(gain) { score += gain; return score; },
    lire() { return score; },
  };
}
const s = creerScore(2);
console.log(s.ajouter(3), s.lire()); // 5 5
```

Dans un vrai projet, valide `initial` et `gain` avant la mutation.

**3. Closures** : chaque appel de `creerCompteur()` possède sa variable `valeur`. Après un premier appel de `a()` puis de `b()`, les deux peuvent renvoyer `1` ; un deuxième appel de `a()` renvoie `2`.

**4. Fléchée** : `const pair = (n) => n % 2 === 0;`.

## Leçon 05

**1. Filtrer et sommer** :

```js
const resultat = [4, 8, 2, 10]
  .filter((x) => x % 2 === 0 && x > 4)
  .reduce((s, x) => s + x, 0);
console.log(resultat); // 18
```

**2. Moyenne** :

```js
function moyenneScores(joueurs) {
  if (joueurs.length === 0) return null;
  const somme = joueurs.reduce((s, j) => s + j.points, 0);
  return somme / joueurs.length;
}
```

**3. Classement non destructif** : `const classement = [...joueurs].sort((a, b) => b.points - a.points);`.

**4. Copie** : `const copie = [...joueurs]` crée un nouveau conteneur, mais les éléments objets restent les **mêmes références**.

## Leçon 06

**1. Match** :

```js
const match = {
  id: 'm1',
  joueurA: { id: 1, pseudo: 'Ada' },
  joueurB: { id: 2, pseudo: 'Lin' },
  scores: { a: 2, b: 1 },
  statut: 'termine',
};
console.log(match.joueurA.pseudo, match.joueurB.pseudo);
```

**2. Ami sans doublon ni mutation** :

```js
function ajouterAmi(utilisateur, nouvelId) {
  return { ...utilisateur, amis: [...new Set([...(utilisateur.amis ?? []), nouvelId])] };
}
```

**3. IDs** :

```js
const liste = JSON.parse('[{"id":1},{"id":2}]');
console.log(liste.reduce((s, entree) => s + entree.id, 0)); // 3
```

**4. Validation JSON** : `{ "isAdmin": true }` est du JSON parfaitement valide, mais une API n'a aucune raison d'accepter qu'un client s'octroie les droits admin. Vérifier **schéma ET autorisation**.

## Leçon 07

**1. Réinitialisation** :

```js
// Après avoir défini score et zone comme dans la leçon :
document.querySelector('#reset').addEventListener('click', () => {
  score = 0;
  zone.textContent = 'Score : 0';
});
```

Ajouter un `<button id="reset" type="button">Réinitialiser</button>`.

**2. Valeur du champ** :

```js
function lirePoints(saisie) {
  if (!/^\d+$/.test(saisie)) return null;
  const n = Number(saisie);
  return Number.isSafeInteger(n) ? n : null;
}
```

**3. Liste sécurisée** :

```js
const ul = document.querySelector('#joueurs');
for (const nom of ['<script>alerte</script>', 'Ada']) {
  const li = document.createElement('li');
  li.textContent = nom;
  ul.append(li);
}
```

**4. Clavier** : tester Tab, Entrée et Espace sur boutons et formulaire natifs, vérifier focus visible et messages lisibles. Il s'agit d'un **test manuel**, pas d'une unique réponse de code.

## Leçon 08

**1. Ordre** : `A`, `D`, `C`, `B` — code synchrone, puis microtâches Promise, puis tâche timer.

**2. Attente** :

```js
const attendre = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function attendreEtDoubler(n) {
  await attendre(100);
  return n * 2;
}
```

**3. 401** :

```js
const reponse = await fetch('/api/joueurs');
if (reponse.status === 401) throw new Error('Non connecté');
if (!reponse.ok) throw new Error(`Erreur HTTP ${reponse.status}`);
```

**4. Pannes** : réseau / DNS / TLS, refus CORS côté navigateur, annulation `AbortError`, HTTP 4xx/5xx (à détecter via `.ok`), JSON malformé, structure inattendue, timeout applicatif si défini.

## Leçon 09

**1. Route** — ajouter **avant** le 404 dans le callback :

```js
if (req.method === 'GET' && url.pathname === '/api/sante') {
  res.writeHead(200);
  res.end(JSON.stringify({ status: 'ok' }));
  return;
}
```

**2. JSON malformé / pseudo court** : dans l'exemple, les deux produisent **400** ; avec des messages différents, il serait possible de mieux distinguer les erreurs. Pour une API réelle, traiter spécifiquement le dépassement de taille par **413** et définir un contrat de réponses.

**3. Vérification serveur** : le navigateur est contrôlé par son utilisateur ; il peut modifier le JS ou envoyer directement des requêtes `curl`. Le serveur vérifie lui-même les règles.

**4. Trajet** : formulaire → écouteur `submit` → `fetch(POST)` → serveur → validation → stockage → réponse JSON + statut → `await` → mise à jour du DOM.

## Leçon 10

**1. Découpage** :

```js
function ajouterPoints(score, gain) { return score + gain; } // métier
function afficherScore(element, score) { element.textContent = `Score : ${score}`; } // DOM
```

**2. Export/import** :

```js
// validation.mjs
export const estPseudoValide = (pseudo) =>
  typeof pseudo === 'string' && pseudo.trim().length >= 3 && pseudo.trim().length <= 20;

// main.mjs
import { estPseudoValide } from './validation.mjs';
console.log(estPseudoValide('Ada'));
```

**3. Vérité** : thème sombre et menu ouvert : **état local** (optionnellement préférences sauvegardées). Mot de passe : ne pas le stocker en clair côté client ; la vérification des secrets relève du serveur. Score gagné : **serveur/base de données**.

**4. Globals** : elles augmentent le couplage, les effets de bord et compliquent les tests ; mieux vaut un module avec API explicite.

## Leçon 11

**1. Deux onglets** : chacun reçoit un « bienvenue » lors de sa connexion ; les autres clients déjà présents reçoivent son message `chat`. Les messages envoyés avant qu'un autre onglet n'existe ne sont pas rejoués.

**2. Présence** :

```js
function diffuserPresence(serveur) {
  const message = JSON.stringify({ type: 'presence', nb: serveur.clients.size });
  for (const client of serveur.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(message);
  }
}

serveur.on('connection', (client) => {
  diffuserPresence(serveur);
  client.on('close', () => diffuserPresence(serveur));
});
```

À intégrer dans le serveur de la leçon (et non déclarer deux gestionnaires concurrents par erreur). Le nombre inclut les sockets encore considérées présentes par la bibliothèque.

**3. Champ numérique** : `typeof message.texte !== 'string'` → message ignoré par la démo.

**4. Score autoritaire** : client A → intention au serveur → vérification du match et du droit → calcul de score côté serveur → persistance → diffusion → mise à jour des interfaces.

## Leçon 12

**1. Deux tests supplémentaires** :

```js
test('zéro est valide', () => {
  assert.equal(calculerScore(0, 0), 0);
});
test('refuse un décimal', () => {
  assert.throws(() => calculerScore(1.5, 2), TypeError);
});
```

**2. Cas de test** : deux clients connectés, deux actions de création simultanées avec données valides, résultat attendu : deux objets distincts, IDs uniques, données non écrasées. Les IDs en mémoire basés sur la longueur d'un tableau ne sont pas un substitut à une vraie stratégie de concurrence multi-processus.

**3. Menaces** : XSS = code non fiable interprété dans le navigateur ; injection SQL = entrée non fiable incorporée dans une requête SQL ; défaut d'autorisation = action interdite acceptée par le serveur.

**4. Peer-évaluation** : démarrage en une commande via conteneurs, tests de plusieurs utilisateurs, inspection console Chrome sans erreur JS, validation frontend/backend, HTTPS et pages légales utiles ; pouvoir expliquer ses choix et ses commits.

---

## Comment s'auto-évaluer

Pour chaque exercice, accorde-toi 0 à 2 points : **0** non compris, **1** fait avec aide, **2** fait seul et expliqué. Reprends uniquement les exercices notés 0 ou 1 après 48 h ; ne relis pas passivement tout le cours.
