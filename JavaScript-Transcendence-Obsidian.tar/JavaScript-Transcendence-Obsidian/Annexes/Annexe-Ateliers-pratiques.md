# Annexe — Ateliers guidés : DOM → API → WebSocket

## Atelier A — Compteur dans le navigateur (30 min)

**Objectif** : un score affiché et deux boutons. Lance `Exemples/dom.html` via serveur local :

```bash
python3 -m http.server 8000
# http://127.0.0.1:8000/Exemples/dom.html
```

**À observer** : le score change sans rechargement ; un pseudo saisi dans un formulaire est ajouté via `createElement` et `textContent`. Le code se trouve dans `Exemples/dom.js`.

**À modifier toi-même** :
1. Mettre un plafond à 20 points.
2. Désactiver le bouton `+1` au plafond.
3. Afficher un message accessible quand le plafond est atteint.
4. Ajouter un test manuel de parcours clavier.

**À expliquer** : pourquoi on manipule `textContent` au lieu d'injecter une chaîne via `innerHTML`.

## Atelier B — API HTTP et contrat (45 min)

```bash
node Exemples/api.mjs
curl -i http://127.0.0.1:3000/api/joueurs
curl -i -X POST http://127.0.0.1:3000/api/joueurs \
  -H 'Content-Type: application/json' -d '{"pseudo":"Ada"}'
```

Le code complet `Exemples/api.mjs` contient une validation de pseudo, une limite de taille **en octets**, des statuts explicites et un stockage temporaire en mémoire. **Il reste une démo**, pas un serveur de production.

| Scénario | Statut attendu |
|---|---|
| GET collection | 200 |
| POST pseudo `Ada` | 201 |
| POST pseudo trop court | 400 |
| POST corps JSON invalide | 400 |
| POST corps trop grand | 413 |
| route inconnue | 404 |

**Challenge** : ajouter `GET /api/sante` et écrire au moins un test `curl` de non-régression pour la route.

## Atelier C — WebSocket avec deux clients (60 min)

```bash
cd Exemples
npm install
node ws-server.mjs
```

Dans un **autre terminal** :

```bash
python3 -m http.server 8000
```

Navigue vers `http://127.0.0.1:8000/ws-client.html` depuis le répertoire `Exemples/` comme répertoire courant. Ouvre un second onglet : un message envoyé depuis A apparaît chez B et inversement.

**À observer** :
- La connexion persiste après l'arrivée du premier message.
- Le serveur diffuse aux autres sockets ouvertes ; il ne retransmet pas les messages historiques.
- Chaque client affiche un statut connexion/déconnexion.
- Un message trop long est refusé côté application ; la limite des trames est aussi contrôlée côté serveur.

**Challenge** : ajouter un événement de présence, puis mesurer l'effet d'une fermeture d'onglet. Les reconnexions ne seront pas instantanées ni garanties par l'exemple : c'est un sujet de conception.

## Atelier D — Cycle TDD (30 min)

1. Écris un test qui échoue pour un score négatif.
2. Écris la validation minimale pour faire passer le test.
3. Ajoute un test pour zéro, un autre pour un décimal, un autre pour le dépassement d'entier sûr.
4. Refactorise sans casser le comportement.

```bash
node --test Exemples/scores.test.mjs
```

**Question centrale** : quelle preuve aurais-tu que le code fonctionnait avant de le modifier, et quelle preuve as-tu après ?
