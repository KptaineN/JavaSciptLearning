# Annexe — Installer et lancer les exemples

## Pré-requis Linux (Mint / Ubuntu)

- Node.js **récent** (recommandé : version LTS maintenue), npm, VSCode ou autre éditeur.
- Firefox ou Chrome, onglet Console et Réseau des devtools.
- Terminal, `curl` et, pour les fichiers statiques, Python 3 facultatif.

```bash
node --version
npm --version
curl --version
```

Si Node.js n'est pas disponible sur une machine sans `sudo`, utilise un gestionnaire de versions installé **dans ton dossier utilisateur** après vérification des instructions officielles, ou la version déjà proposée par l'environnement scolaire. Évite d'exécuter à l'aveugle des scripts téléchargés.

## Extraire le parcours

```bash
tar -xf JavaScript-Transcendence-Obsidian.tar
cd JavaScript-Transcendence-Obsidian
```

Dans Obsidian : **Ouvrir un autre coffre** → **Ouvrir un dossier comme coffre** → dossier extrait. Si tu possèdes déjà un vault, tu peux simplement y copier les répertoires et `00-Accueil.md`.

## Ouvrir un programme Node

```bash
node Exemples/scores.mjs
node --test Exemples/scores.test.mjs
```

Les fichiers `.mjs` activent la syntaxe `import/export` des modules ECMAScript dans Node, sans `package.json` particulier.

## Ouvrir le navigateur

Depuis la racine du vault :

```bash
python3 -m http.server 8000
```

Puis ouvrir `http://127.0.0.1:8000/Exemples/dom.html`. C'est un **serveur de fichiers pour le développement local**, non un serveur backend de production.

## Démarrer l'API Node

Dans un autre terminal :

```bash
node Exemples/api.mjs
curl -i http://127.0.0.1:3000/api/joueurs
```

Le serveur écoute **uniquement sur 127.0.0.1** et stocke tout en mémoire. L'exemple DOM est autonome ; l'exemple API est séparé pour éviter les problèmes de ports / CORS dès la première leçon.

## Démarrer WebSocket (atelier avancé)

```bash
cd Exemples
npm install
node ws-server.mjs
```

`npm install` lit `Exemples/package.json` et installe `ws`. Depuis un serveur de fichiers local, ouvre `Exemples/ws-client.html` dans **deux onglets**. La connexion est locale en `ws://127.0.0.1:8080`.

## Commandes rapides

| Tâche | Commande |
|---|---|
| Exécuter fichier | `node fichier.mjs` |
| Tests intégrés | `node --test fichier.test.mjs` |
| Vérifier une syntaxe | `node --check fichier.mjs` |
| Ouvrir serveur statique | `python3 -m http.server 8000` |
| Voir port occupé | `ss -ltnp` |
| Requête API | `curl -i http://127.0.0.1:3000/api/joueurs` |
| Arrêter un serveur terminal | `Ctrl+C` |

## Résoudre les erreurs les plus fréquentes

- `ReferenceError: document is not defined` : tu as lancé dans **Node** du code prévu pour le navigateur.
- `Cannot use import statement outside a module` : vérifie la configuration ES modules (`.mjs`, `"type": "module"`, ou script navigateur `type="module"`).
- `ERR_MODULE_NOT_FOUND` : chemin import invalide ou package manquant.
- `EADDRINUSE` : port déjà utilisé ; ferme l'ancien serveur ou change de port.
- `Failed to fetch` : serveur éteint, mauvaise origine, problème CORS/réseau ou TLS.
- Page blanche : regarde Console et Network **avant** de changer du code au hasard.
