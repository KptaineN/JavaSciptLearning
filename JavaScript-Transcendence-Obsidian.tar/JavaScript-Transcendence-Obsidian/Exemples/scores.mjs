/** Logique métier simple et testable. Aucun DOM, aucune requête réseau. */
export function calculerScore(score, gain) {
  if (!Number.isSafeInteger(score) || !Number.isSafeInteger(gain)) {
    throw new TypeError('Entiers attendus');
  }
  if (score < 0 || gain < 0 || !Number.isSafeInteger(score + gain)) {
    throw new RangeError('Score invalide');
  }
  return score + gain;
}

export function classement(joueurs) {
  return [...joueurs].sort((a, b) => b.score - a.score);
}
