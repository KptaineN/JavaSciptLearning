import http from 'node:http';

// Démonstration locale pédagogique : ni authentification ni stockage durable.
const joueurs = [{ id: 1, pseudo: 'Ada' }];
let dernierId = 1;
const MAX_BODY_BYTES = 4096;

function envoyer(res, status, valeur) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(valeur));
}

async function lireJson(req) {
  let taille = 0;
  const blocs = [];
  let depasse = false;

  // On lit le flux jusqu'à son terme même si la limite est dépassée.
  for await (const bloc of req) {
    taille += bloc.length;
    if (taille > MAX_BODY_BYTES) depasse = true;
    if (!depasse) blocs.push(bloc);
  }
  if (depasse) return { erreur: 'trop-grand' };
  try {
    return { valeur: JSON.parse(Buffer.concat(blocs).toString('utf8')) };
  } catch {
    return { erreur: 'json-invalide' };
  }
}

const serveur = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  if (req.method === 'GET' && url.pathname === '/api/joueurs') {
    envoyer(res, 200, joueurs);
    return;
  }

  if (req.method === 'POST' && url.pathname === '/api/joueurs') {
    try {
      const resultat = await lireJson(req);
      if (resultat.erreur === 'trop-grand') {
        envoyer(res, 413, { erreur: 'Corps trop grand' });
        return;
      }
      if (resultat.erreur) {
        envoyer(res, 400, { erreur: 'JSON invalide' });
        return;
      }
      const entree = resultat.valeur;
      if (!entree || typeof entree.pseudo !== 'string') {
        envoyer(res, 400, { erreur: 'Pseudo attendu' });
        return;
      }
      const pseudo = entree.pseudo.trim();
      if (pseudo.length < 3 || pseudo.length > 20) {
        envoyer(res, 400, { erreur: 'Pseudo de 3 à 20 caractères' });
        return;
      }
      const joueur = { id: ++dernierId, pseudo };
      joueurs.push(joueur);
      envoyer(res, 201, joueur);
    } catch {
      if (!res.headersSent) envoyer(res, 400, { erreur: 'Requête illisible' });
    }
    return;
  }

  envoyer(res, 404, { erreur: 'Route introuvable' });
});

serveur.listen(3000, '127.0.0.1', () => {
  console.log('API locale : http://127.0.0.1:3000/api/joueurs');
});
