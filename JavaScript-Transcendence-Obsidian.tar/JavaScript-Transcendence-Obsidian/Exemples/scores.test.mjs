import test from 'node:test';
import assert from 'node:assert/strict';
import { calculerScore, classement } from './scores.mjs';

test('additionne un gain valide', () => {
  assert.equal(calculerScore(2, 3), 5);
});

test('accepte un score nul', () => {
  assert.equal(calculerScore(0, 0), 0);
});

test('rejette les nombres négatifs', () => {
  assert.throws(() => calculerScore(2, -1), RangeError);
});

test('rejette les décimaux', () => {
  assert.throws(() => calculerScore(1.5, 2), TypeError);
});

test('rejette les dépassements d’entier sûr', () => {
  assert.throws(() => calculerScore(Number.MAX_SAFE_INTEGER, 1), RangeError);
});

test('trie sans modifier le tableau d’origine', () => {
  const data = [{ pseudo: 'B', score: 1 }, { pseudo: 'A', score: 3 }];
  const sorted = classement(data);
  assert.equal(sorted[0].pseudo, 'A');
  assert.equal(data[0].pseudo, 'B');
});
