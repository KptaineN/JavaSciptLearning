# Exemples exécutables — Mode d'emploi

| Fichier | Comment l'exécuter | Prérequis |
|---|---|---|
| `scores.mjs` | importer dans tests ou autre module | Node récent |
| `scores.test.mjs` | `node --test scores.test.mjs` | Node récent |
| `dom.html`, `dom.js` | serveur statique + navigateur | navigateur |
| `api.mjs` | `node api.mjs` puis `curl` | Node récent |
| `ws-server.mjs` | `npm install` puis `node ws-server.mjs` | Node récent + ws |
| `ws-client.html` | serveur statique + navigateur (2 onglets) | serveur WS actif |

Tous les serveurs se lient à **127.0.0.1** et n'ont **pas** l'authentification, la persistance ni le TLS nécessaires à un déploiement réel. L'objectif est de **comprendre le mécanisme**, pas de prendre le code comme modèle prêt pour la production.

```bash
# Depuis le dossier Exemples/
node --test scores.test.mjs
node api.mjs

# Dans un autre terminal :
curl -i http://127.0.0.1:3000/api/joueurs
```

Pour les fichiers HTML, lance `python3 -m http.server 8000` depuis **Exemples/** puis visite `http://127.0.0.1:8000/dom.html` ou `http://127.0.0.1:8000/ws-client.html`.

Pour tester le WebSocket, installe `ws` depuis ce même dossier avec `npm install` ; aucun des autres exemples n'en a besoin.
