'use strict';
const afficher = document.querySelector('#score');
const boutonPlus = document.querySelector('#plus');
const boutonReset = document.querySelector('#reset');
const formulaire = document.querySelector('#creation');
const retour = document.querySelector('#retour');
const liste = document.querySelector('#joueurs');
let score = 0;

function mettreAJourScore() {
  afficher.textContent = `Score : ${score}`;
}

function ajouterJoueur(pseudo) {
  const li = document.createElement('li');
  li.textContent = pseudo;
  liste.append(li);
}

boutonPlus.addEventListener('click', () => {
  score += 1;
  mettreAJourScore();
});

boutonReset.addEventListener('click', () => {
  score = 0;
  mettreAJourScore();
});

formulaire.addEventListener('submit', (event) => {
  event.preventDefault();
  const pseudo = formulaire.elements.namedItem('pseudo').value.trim();
  if (pseudo.length < 3 || pseudo.length > 20) {
    retour.textContent = 'Le pseudo doit contenir entre 3 et 20 caractères.';
    return;
  }
  ajouterJoueur(pseudo); // pas de innerHTML : entrée non fiable affichée comme texte
  retour.textContent = `${pseudo} ajouté.`;
  formulaire.reset();
});

ajouterJoueur('Ada');
ajouterJoueur('Lin');
