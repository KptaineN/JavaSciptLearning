import { WebSocketServer, WebSocket } from 'ws';

// Démonstration locale seulement : aucune identité/auth/session n'est vérifiée.
const serveur = new WebSocketServer({
  host: '127.0.0.1',
  port: 8080,
  maxPayload: 4096,
});

function diffuser(message, emetteur = null) {
  const texte = JSON.stringify(message);
  for (const client of serveur.clients) {
    if (client !== emetteur && client.readyState === WebSocket.OPEN) {
      // Exemple de garde rudimentaire ; définir une vraie politique de backpressure.
      if (client.bufferedAmount > 65536) continue;
      client.send(texte);
    }
  }
}

serveur.on('connection', (client) => {
  client.send(JSON.stringify({ type: 'bienvenue' }));
  diffuser({ type: 'presence', total: serveur.clients.size });

  client.on('message', (donnees, estBinaire) => {
    if (estBinaire) return;
    let message;
    try {
      message = JSON.parse(donnees.toString('utf8'));
    } catch {
      client.send(JSON.stringify({ type: 'erreur', texte: 'JSON invalide' }));
      return;
    }
    if (!message || message.type !== 'chat' || typeof message.texte !== 'string') return;
    const texte = message.texte.trim();
    if (texte.length < 1 || texte.length > 200) return;
    diffuser({ type: 'chat', texte }, client);
  });

  client.on('close', () => {
    diffuser({ type: 'presence', total: serveur.clients.size });
  });
});

console.log('WebSocket local : ws://127.0.0.1:8080');
