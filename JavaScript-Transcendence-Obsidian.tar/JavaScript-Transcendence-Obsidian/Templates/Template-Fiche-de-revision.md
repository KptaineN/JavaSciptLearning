---
type: fiche-revision
concept:
statut: a-revoir
derniere_revision:
prochaine_revision:
tags: [javascript, revision]
---

# Concept — À compléter

## Je peux l'expliquer en une phrase

...

## Exemple écrit sans aide

```js
// Ton exemple
```

## Erreur que j'ai faite

...

## Comment je la détecte

...

## Mini-quiz personnel

1. 
2. 
3. 

## Ressources / liens Obsidian

- [[00-Accueil]]
