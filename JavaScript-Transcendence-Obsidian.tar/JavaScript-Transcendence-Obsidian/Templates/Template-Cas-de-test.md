---
type: cas-de-test
id: TC-000
domaine: a-definir
priorite: P1
automatisation: a-decider
statut: a-concevoir
source_exigence:
tags: [test, ft-transcendence]
---

# TC-000 — Titre descriptif

## Objectif et traçabilité

- **Exigence associée** : 
- **Risque couvert** : 
- **Type** : unitaire / API / E2E / manuel / charge
- **Priorité** : P0 / P1 / P2

## Préconditions

- [ ] Environnement démarré.
- [ ] Données et comptes de test préparés.

## Données de test

| Variable | Valeur |
|---|---|
| entrée | |

## Étapes

1. 
2. 
3. 

## Résultat attendu

Décrire un comportement **observable et vérifiable** (statut, contenu, affichage, état persistant, absence de fuite...).

## Exécution

- **Date** :
- **Environnement** :
- **Résultat obtenu** :
- **Statut** : non-exécuté / réussi / échoué / bloqué
- **Preuve** : capture, réponse HTTP, logs, rapport, lien bug

## Automatisation

- **Outil** :
- **Script / chemin** :
- **À rejouer après correction ?** oui / non
